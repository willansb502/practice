<?php


define('UC_CONNECT', 'mysql');

define('UC_DBHOST', 'localhost');
define('UC_DBUSER', '98_142_141_157');
define('UC_DBPW', 'c3mkKNPnbZnPbnFW');
define('UC_DBNAME', '98_142_141_157');
define('UC_DBCHARSET', 'gbk');
define('UC_DBTABLEPRE', '`98_142_141_157`.pre_ucenter_');
define('UC_DBCONNECT', 0);

define('UC_CHARSET', 'gbk');
define('UC_KEY', 'O6bbGcA9E230G3aep417Ecm953D28fd8ecX5M0g088f60al4cf99h1z8Ucs6y2J8');
define('UC_API', 'http://98.142.141.157/uc_server');
define('UC_APPID', '1');
define('UC_IP', '');
define('UC_PPP', 20);
?>