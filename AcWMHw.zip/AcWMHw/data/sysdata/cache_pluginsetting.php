<?php
//Discuz! cache file, DO NOT modify me!
//Identify: c80cc40890ce3c28508a02ad37677066

$pluginsetting = array (
);
?>