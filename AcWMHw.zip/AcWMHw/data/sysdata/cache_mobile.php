<?php
//Discuz! cache file, DO NOT modify me!
//Identify: 2c883ed1f288a3aac98fdcc63403cb41

$mobilecheck = '{"discuzversion":"X3.4","charset":"gbk","version":"4","pluginversion":"1.4.8","oemversion":"0","regname":"register","qqconnect":"0","sitename":"Discuz! Board","mysiteid":"","ucenterurl":"http:\\/\\/98.142.141.157\\/uc_server","setting":{"closeforumorderby":null},"extends":{"used":null,"lastupdate":null}}';
?>