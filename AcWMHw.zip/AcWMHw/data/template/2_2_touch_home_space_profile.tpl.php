<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); hookscriptoutput('space_profile');?>
<?php if($_GET['mycenter'] && !$_G['uid']) { dheader('Location:member.php?mod=logging&action=login');exit;?><?php } include template('common/header'); include template('home/space_head'); ?><style type="text/css">
body{background: #fff!important;}
.mobanbus_header .busleft, .mobanbus_header .busmoreshare, .footer{display: none;}
</style>
<div class="bus_w100 bus_fl">
<div class="bus_profile">

<div class="mobanbus_ajax bus_piclist mt20 busbox"><?php $busspace = DB::fetch_all("SELECT * FROM ".DB::table('forum_thread')." WHERE `authorid`= '$space[uid]' ORDER BY dateline DESC");?><?php if($busspace) { ?>
<div class="hidden"><?php if(is_array($busspace)) foreach($busspace as $thread) { ?><li class="clt busload busbox fadeIn animated">
<div class="bus_pics">
<a href="forum.php?mod=viewthread&amp;tid=<?php echo $thread['tid'];?>" class="preview"><?php $busid = substr($thread[tid], -1); $cover = DB::result(DB::query("SELECT count(*) FROM ".DB::table('forum_attachment_'.$busid.'')." WHERE tid = '$thread[tid]' and isimage = '1'"));?><?php if($cover > 0) { $pics = DB::fetch_all("SELECT * FROM ".DB::table('forum_attachment_'.$busid.'')." WHERE `tid`= $thread[tid] ORDER BY `dateline` and isimage = '1' DESC limit 1");?><?php if(is_array($pics)) foreach($pics as $pic) { $imagelistkey = getforumimg($pic[aid], 0, 400, 400);?><img src="template/mobanbus_motev1/mobanbus_st/img/busnomsg.jpg" data-src="<?php echo $imagelistkey;?>">
<?php } } else { ?>
<img src="template/mobanbus_motev1/mobanbus_st/img/busnomsg.jpg">
<?php } ?>

</a>
<div class="bus_piclist_info">
<h2><a href="forum.php?mod=viewthread&amp;tid=<?php echo $thread['tid'];?>"><?php echo $thread['subject'];?></a></h2>
<div class="clear"></div>
<span class="bus_fl"><?php echo $thread['views'];?> ���</span>
</div>
</div>
</li>
<?php } ?>
</div>

<div class="clear"></div>
<ul class="list"><span class="spinner-loader"></span></ul>
<div class="more"><a href="javascript:;" onClick="mobanbus_ajax.loadMore();">�鿴����</a></div>

<?php } else { ?>
<div class="busnomsg">��û����ص�����</div>
<?php } ?>

</div><!-- Mobanbus_cn END bus_piclist -->
<script src="<?php echo $_G['siteurl'];?>template/mobanbus_motev1/mobile_st/js/mobanbus_lazy.js" type="text/javascript"></script>
<script src="<?php echo $_G['siteurl'];?>template/mobanbus_motev1/mobile_st/js/mobanbus_ajax.min.js" type="text/javascript"></script>	


</div><!-- main bus_profile end -->
</div><!-- main bus_w100 end --><?php include template('common/footer'); ?>