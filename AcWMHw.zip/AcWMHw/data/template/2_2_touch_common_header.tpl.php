<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo CHARSET;?>">
<meta http-equiv="Cache-control" content="<?php if($_G['setting']['mobile']['mobilecachetime'] > 0) { ?><?php echo $_G['setting']['mobile']['mobilecachetime'];?><?php } else { ?>no-cache<?php } ?>" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0">
<meta name="format-detection" content="telephone=no" />
<meta name="keywords" content="<?php if(!empty($metakeywords)) { echo dhtmlspecialchars($metakeywords); } ?>" />
<meta name="description" content="<?php if(!empty($metadescription)) { echo dhtmlspecialchars($metadescription); ?> <?php } ?>,<?php echo $_G['setting']['bbname'];?>" />
<title><?php if(!empty($navtitle)) { ?><?php echo $navtitle;?> - <?php } if(empty($nobbname)) { ?> <?php echo $_G['setting']['bbname'];?> - <?php } ?> �ֻ��� - Powered by Discuz!</title>
<script type="text/javascript">var STYLEID = '<?php echo STYLEID;?>', STATICURL = '<?php echo STATICURL;?>', IMGDIR = '<?php echo IMGDIR;?>', VERHASH = '<?php echo VERHASH;?>', charset = '<?php echo CHARSET;?>', discuz_uid = '<?php echo $_G['uid'];?>', cookiepre = '<?php echo $_G['config']['cookie']['cookiepre'];?>', cookiedomain = '<?php echo $_G['config']['cookie']['cookiedomain'];?>', cookiepath = '<?php echo $_G['config']['cookie']['cookiepath'];?>', showusercard = '<?php echo $_G['setting']['showusercard'];?>', attackevasive = '<?php echo $_G['config']['security']['attackevasive'];?>', disallowfloat = '<?php echo $_G['setting']['disallowfloat'];?>', creditnotice = '<?php if($_G['setting']['creditnotice']) { ?><?php echo $_G['setting']['creditnames'];?><?php } ?>', defaultstyle = '<?php echo $_G['style']['defaultextstyle'];?>', REPORTURL = '<?php echo $_G['currenturl_encode'];?>', SITEURL = '<?php echo $_G['siteurl'];?>', JSPATH = '<?php echo $_G['setting']['jspath'];?>', CSSPATH = '<?php echo $_G['setting']['csspath'];?>', DYNAMICURL = '<?php echo $_G['dynamicurl'];?>';</script>

<link rel="stylesheet" href="<?php echo $_G['siteurl'];?>template/mobanbus_motev1/mobile_st/css/mobanbus_motev1_st.css" media="screen" />
<link rel="stylesheet" href="<?php echo $_G['siteurl'];?>template/mobanbus_motev1/mobile_st/css/swiper.min.css" media="screen" />
<link rel="stylesheet" href="<?php echo $_G['siteurl'];?>template/mobanbus_motev1/mobile_st/css/animate.min.css">
<link rel="stylesheet" href="<?php echo $_G['siteurl'];?>template/mobanbus_motev1/mobile_st/css/mobanbus.min.css" />
<link rel="stylesheet" href="<?php echo $_G['siteurl'];?>template/mobanbus_motev1/mobanbus_st/css/buttons.css" />

</head>
<body class="mobanbus page-container"> 
<?php if(!empty($_G['setting']['pluginhooks']['global_header_mobile'])) echo $_G['setting']['pluginhooks']['global_header_mobile'];?>


<?php if($_GET['mod'] == 'index') { ?>
<script src="<?php echo $_G['siteurl'];?>template/mobanbus_motev1/mobile_st/js/common.js?<?php echo VERHASH;?>" type="text/javascript" charset="<?php echo CHARSET;?>"></script>
<script src="<?php echo $_G['siteurl'];?>template/mobanbus_motev1/mobile_st/js/jQuery.js" type="text/javascript" charset="<?php echo CHARSET;?>"></script>

<?php } elseif($_GET['mod'] == 'misc' || $_GET['mod'] == 'post') { ?>
<div id="append_parent"></div>
<script type="text/javascript">
document.ready = function (){
var wechatInfo = navigator.userAgent.match(/MicroMessenger\/([\d\.]+)/i) ;
if( !wechatInfo ) {
document.getElementById("mobanbushead").className+=" bus_box";
} else if ( wechatInfo[1] ) {
document.getElementById("mobanbushead").className+=" bus_hide";
}
}
</script>

<!-- Mobanbus_cn header start -->
<header id="mobanbushead" class="mobanbus_header bus_index">
  <div class="bus_nav">
<div class="ico busleft">
<a href="javascript:history.go(-1);"><i class="icon-angle-left"></i></a>
</div>
<div class="logo_index">
<h1 class="bus_logo"><?php echo $navtitle;?></h1>
</div>
  </div>
  <div class="clear"></div>
<div class="bus_indexBOX"></div>
</header>
<!-- Mobanbus_cn header end -->



<?php } else { ?>
<div id="append_parent"></div><div id="ajaxwaitid"></div>
<script src="<?php echo $_G['siteurl'];?>template/mobanbus_motev1/mobile_st/js/common.js?<?php echo VERHASH;?>" type="text/javascript" charset="<?php echo CHARSET;?>"></script>
<script src="<?php echo $_G['siteurl'];?>template/mobanbus_motev1/mobile_st/js/jQuery.js" type="text/javascript" charset="<?php echo CHARSET;?>"></script>

<script type="text/javascript">
document.ready = function (){
var wechatInfo = navigator.userAgent.match(/MicroMessenger\/([\d\.]+)/i) ;
if( !wechatInfo ) {
document.getElementById("mobanbushead").className+=" bus_box";
} else if ( wechatInfo[1] ) {
document.getElementById("mobanbushead").className+=" bus_hide";
}
}
</script>

<!-- Mobanbus_cn header start -->
<header id="mobanbushead" class="mobanbus_header bus_index">
  <div class="bus_nav">
<div class="ico busleft">
<a href="javascript:history.go(-1);"><i class="icon-angle-left"></i></a>
</div>
<div class="logo_index">
<h1 class="bus_logo"><?php echo $navtitle;?></h1>
</div>
  </div>
  <div class="clear"></div>
<div class="bus_indexBOX"></div>
</header>
<!-- Mobanbus_cn header end -->




<?php } ?>


<section class="mobanbus_wrap">
<section class="bus_warp busbox">