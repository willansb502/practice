<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); hookscriptoutput('index');
block_get('3');?><?php include template('common/header'); require_once("template/mobanbus_motev1/php/index_ajax.php");?><script src="<?php echo $_G['siteurl'];?>template/mobanbus_motev1/mobile_st/js/mobanbus_lazy.js" type="text/javascript"></script>
<script src="<?php echo $_G['siteurl'];?>template/mobanbus_motev1/mobile_st/js/mobanbus_swiper.js" type="text/javascript"></script><?php block_display('3');?><div class="bus_piclist mobanbus_ajax busbox mt20">
<div class="hidden"><?php if(is_array($manylist)) foreach($manylist as $thread) { $list_count+=1;?>  

<li class="clt busload busbox fadeIn animated">
<div class="bus_pics">
<a href="forum.php?mod=viewthread&amp;tid=<?php echo $thread['tid'];?>" class="preview"><?php $busid = substr($thread[tid], -1); $cover = DB::result(DB::query("SELECT count(*) FROM ".DB::table('forum_attachment_'.$busid.'')." WHERE tid = '$thread[tid]' and isimage = '1'"));?><?php if($cover > 0) { $pics = DB::fetch_all("SELECT * FROM ".DB::table('forum_attachment_'.$busid.'')." WHERE `tid`= $thread[tid] ORDER BY `dateline` and isimage = '1' DESC limit 1");?><?php if(is_array($pics)) foreach($pics as $pic) { $imagelistkey = getforumimg($pic[aid], 0, 400, 400);?><img src="template/mobanbus_motev1/mobanbus_st/img/busnomsg.jpg" data-src="<?php echo $imagelistkey;?>">
<?php } } else { ?>
<img src="template/mobanbus_motev1/mobanbus_st/img/busnomsg.jpg">
<?php } ?>

</a>
<div class="bus_piclist_info">
<h2><a href="forum.php?mod=viewthread&amp;tid=<?php echo $thread['tid'];?>"><?php echo $thread['subject'];?></a></h2>
<div class="clear"></div>
<span class="bus_fl"><?php echo $thread['views'];?> ���</span>
</div>
</div>
</li>
<?php } ?>

</div>
<ul class="list">���ݼ����У����Ժ�...</ul>
<div class="more"><a href="javascript:;" class="bus_loadbutton" onClick="mobanbus_ajax.loadMore();">�鿴����</a></div>
</div>


<script src="template/mobanbus_motev1/mobile_st/js/mobanbus_ajax.min.js" type="text/javascript"></script>	

<script>
var swiper = new Swiper('.bus_indexslider', {
loop : true,
autoplay:true,
pagination: {
el: '.swiper-pagination',
      },
    });
</script><?php include template('common/footer'); ?>