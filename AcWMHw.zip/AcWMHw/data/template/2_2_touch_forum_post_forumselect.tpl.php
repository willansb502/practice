<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); hookscriptoutput('post_forumselect');?><?php include template('common/header'); ?><script src="<?php echo $_G['siteurl'];?>template/mobanbus_motev1/mobile_st/js/common.js?<?php echo VERHASH;?>" type="text/javascript" charset="<?php echo CHARSET;?>"></script>
<style type="text/css">
.bus_replyfix, .bus_bottomnav{display: none;}
</style><?php $busallforuma = DB::fetch_all("SELECT * FROM ".DB::table('forum_forum')." WHERE `status`= '1' AND `type`= 'group'");?><?php if(is_array($busallforuma)) foreach($busallforuma as $busa) { ?><div class="bus_forumbd">
<div class="bus_forum_tt cl">
<h2><a href="#"><?php echo $busa['name'];?></a></h2>
</div>
<div class="bus_forum">
<ul><?php $busallforumb = DB::fetch_all("SELECT * FROM ".DB::table('forum_forum')." a left join ".DB::table("forum_forumfield")." b on a.fid=b.fid WHERE a.`type`= 'forum' and a.`fup` = '$busa[fid]'  and a.`status` = 1 ");?><?php if(is_array($busallforumb)) foreach($busallforumb as $busb) { ?><li>
<div class="bus_forum_pic">
<?php if($busb['icon']) { ?>
            <a href="forum.php?mod=post&amp;action=newthread&amp;fid=<?php echo $busb['fid'];?>"><img src="data/attachment/common/<?php echo $busb['icon'];?>" /></a>
            <?php } else { ?>
<a href="forum.php?mod=post&amp;action=newthread&amp;fid=<?php echo $busb['fid'];?>"><img src="<?php echo $_G['style']['styleimgdir'];?>/forum<?php if($forum['folder']) { ?>_new<?php } ?>.gif" /></a>
            <?php } ?>
<div class="bus_forum_txt">
<a href="forum.php?mod=post&amp;action=newthread&amp;fid=<?php echo $busb['fid'];?>">
<div><?php echo $busb['name'];?></div>
</a>	
</div>
</div>
</li>
<?php } ?>
</ul>
</div>
</div>
<?php } include template('common/footer'); ?>