<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); hookscriptoutput('index');?><?php include template('common/header'); require_once("template/mobanbus_motev1/php/index_ajax.php");?><style id="diy_style" type="text/css"></style>


<div class="mobanbus_ajax bus_showbd bus_newslist mt30 pd10"><?php if(is_array($manylist)) foreach($manylist as $thread) { $list_count+=1;?>  
<div class="bus_postbd">
<div class="bus_vtem">
<a href="forum.php?mod=viewthread&amp;tid=<?php echo $thread['tid'];?>" class="preview"><?php $biaoid = substr($thread[tid], -1); $cover = DB::result(DB::query("SELECT count(*) FROM ".DB::table('forum_attachment_'.$biaoid.'')." WHERE tid = '$thread[tid]' and isimage = '1'"));?><?php if($cover > 0) { $pics = DB::fetch_all("SELECT * FROM ".DB::table('forum_attachment_'.$biaoid.'')." WHERE `tid`= $thread[tid] ORDER BY `dateline` and isimage = '1' DESC limit 1");?><?php if(is_array($pics)) foreach($pics as $pic) { $imagelistkey = getforumimg($pic[aid], 0, 300, 300);?><img src="template/mobanbus_motev1/mobanbus_st/img/busnomsg.jpg" data-src="<?php echo $imagelistkey;?>">
<?php } } else { ?>
<img src="template/mobanbus_motev1/mobanbus_st/img/busnomsg.jpg">
<?php } ?>

</a>
<div class="bus_alumtt">
<div class="t"><?php echo $thread['subject'];?></div>
<div class="clear"></div>
<div class="i"><dl class="bus_fl">���:<i><?php echo $thread['views'];?></i></dl><dl class="bus_fr ml10">�ظ�:<i><?php echo $thread['replies'];?></i></dl></div>
</div>
</div>
</div>
<?php } ?>

<div class="clear"></div>
<?php echo $pagenav;?>
</div>
<!-- Mobanbus END mobanbus_ajax -->

<div class="bus_act mt30 bus_w100 bus_fl">
    <!--[diy=bus_act]--><div id="bus_act" class="area"></div><!--[/diy]-->
</div>
<!-- Mobanbus END bus_act -->

<script src="<?php echo $_G['siteurl'];?>template/mobanbus_motev1/mobanbus_st/js/mobanbus_ajax.min.js" type="text/javascript"></script>	
<script src="<?php echo $_G['siteurl'];?>template/mobanbus_motev1/mobanbus_st/js/mobanbus_lazy.js" type="text/javascript"></script>
<script id="jsID" type="text/javascript">jQuery("#slideBox_top").slide({mainCell:".bd ul",autoPlay:true,easing:"swing"})</script><?php include template('common/footer'); ?>