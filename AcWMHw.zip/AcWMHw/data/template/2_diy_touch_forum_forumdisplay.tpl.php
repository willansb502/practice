<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); hookscriptoutput('forumdisplay');
0
|| checktplrefresh('./template/mobanbus_motev1/touch/forum/forumdisplay.htm', './template/mobanbus_motev1/touch/forum/search_sortoption.htm', 1654050758, 'diy', './data/template/2_diy_touch_forum_forumdisplay.tpl.php', './template/mobanbus_motev1', 'touch/forum/forumdisplay')
;?><?php include template('common/header'); ?><?php if(!empty($_G['setting']['pluginhooks']['forumdisplay_top_mobile'])) echo $_G['setting']['pluginhooks']['forumdisplay_top_mobile'];?>
<!-- Mobanbus threadlist start -->

<?php if(($_G['forum']['threadtypes'] && $_G['forum']['threadtypes']['listable']) || count($_G['forum']['threadsorts']['types']) > 0) { if($_G['forum']['threadtypes']) { ?>
<div class="bus_fenlei busbox">
<ul id="thread_types">
<?php if(!empty($_G['setting']['pluginhooks']['forumdisplay_threadtype_inner'])) echo $_G['setting']['pluginhooks']['forumdisplay_threadtype_inner'];?><?php if(is_array($_G['forum']['threadtypes']['types'])) foreach($_G['forum']['threadtypes']['types'] as $id => $name) { if($_GET['typeid'] == $id) { ?>
<li class="xw1 a"><a href="forum.php?mod=forumdisplay&amp;fid=<?php echo $_G['fid'];?><?php if($_GET['sortid']) { ?>&amp;filter=sortid&amp;sortid=<?php echo $_GET['sortid'];?><?php } if($_GET['archiveid']) { ?>&amp;archiveid=<?php echo $_GET['archiveid'];?><?php } ?>"><?php if($_G['forum']['threadtypes']['icons'][$id] && $_G['forum']['threadtypes']['prefix'] == 2) { ?><img class="vm" src="<?php echo $_G['forum']['threadtypes']['icons'][$id];?>" alt="" /> <?php } ?><?php echo $name;?><?php if($showthreadclasscount['typeid'][$id]) { ?><span class="xg1 num">(<?php echo $showthreadclasscount['typeid'][$id];?>)</span><?php } ?></a></li>
<?php } else { ?>
<li><a href="forum.php?mod=forumdisplay&amp;fid=<?php echo $_G['fid'];?>&amp;filter=typeid&amp;typeid=<?php echo $id;?><?php echo $forumdisplayadd['typeid'];?><?php if($_GET['archiveid']) { ?>&amp;archiveid=<?php echo $_GET['archiveid'];?><?php } ?>"><?php if($_G['forum']['threadtypes']['icons'][$id] && $_G['forum']['threadtypes']['prefix'] == 2) { ?><img class="vm" src="<?php echo $_G['forum']['threadtypes']['icons'][$id];?>" alt="" /> <?php } ?><?php echo $name;?><?php if($showthreadclasscount['typeid'][$id]) { ?><span class="xg1 num">(<?php echo $showthreadclasscount['typeid'][$id];?>)</span><?php } ?></a></li>
<?php } } ?>

<?php if(!empty($_G['setting']['pluginhooks']['forumdisplay_filter_extra'])) echo $_G['setting']['pluginhooks']['forumdisplay_filter_extra'];?>
</ul>
</div>
<?php } if($quicksearchlist && !$_GET['archiveid']) { ?>
<div class="bus_sort_coce"><script type="text/javascript">
var forum_optionlist = <?php if($forum_optionlist) { ?>'<?php echo $forum_optionlist;?>'<?php } else { ?>''<?php } ?>;
</script>
<script src="<?php echo $_G['setting']['jspath'];?>threadsort.js?<?php echo VERHASH;?>" type="text/javascript"></script><?php if(is_array($quicksearchlist)) foreach($quicksearchlist as $optionid => $option) { $formsearch = '';?>        <?php if(getstatus($option['search'], 1)) { ?>
        <?php
$__VERHASH = VERHASH;$formsearch = <<<EOF

            <div style="
EOF;
 if($option['type'] == 'checkbox') { 
$formsearch .= <<<EOF
clear:left;padding-bottom: 5px;
EOF;
 } else { 
$formsearch .= <<<EOF
float: left;width: 48%;height: 30px; overflow: hidden;
EOF;
 } 
$formsearch .= <<<EOF
">
                <span style="padding-right: 1em;">{$option['title']}:</span>
                
EOF;
 if(in_array($option['type'], array('radio', 'checkbox', 'select', 'range'))) { 
$formsearch .= <<<EOF

                    <span id="select_{$option['identifier']}">
                    
EOF;
 if($option['type'] == 'select') { 
$formsearch .= <<<EOF

                        
EOF;
 if($_GET['searchoption'][$optionid]['value']) { 
$formsearch .= <<<EOF

                            <script type="text/javascript">
                                changeselectthreadsort('{$_GET['searchoption'][$optionid]['value']}', {$optionid}, 'search');
                            </script>
                        
EOF;
 } else { 
$formsearch .= <<<EOF

                            <select name="searchoption[{$optionid}][value]" id="{$option['identifier']}" onchange="changeselectthreadsort(this.value, '{$optionid}', 'search');" class="ps vm">
                                <option value="0">��ѡ��</option>
                            
EOF;
 if(is_array($option['choices'])) foreach($option['choices'] as $id => $value) { 
$formsearch .= <<<EOF
                                
EOF;
 if(!$value['foptionid']) { 
$formsearch .= <<<EOF

                                <option value="{$id}">{$value['content']} 
EOF;
 if($value['level'] != 1) { 
$formsearch .= <<<EOF
&raquo;
EOF;
 } 
$formsearch .= <<<EOF
</option>
                                
EOF;
 } 
$formsearch .= <<<EOF

                            
EOF;
 } 
$formsearch .= <<<EOF

                            </select>
<input type="hidden" name="searchoption[{$optionid}][type]" value="{$option['type']}">
                        
EOF;
 } 
$formsearch .= <<<EOF

                    
EOF;
 } elseif($option['type'] != 'checkbox') { 
$formsearch .= <<<EOF

                        <select name="searchoption[{$optionid}][value]" id="{$option['identifier']}" class="ps vm">
                            <option value="0">��ѡ��</option>
                        
EOF;
 if(is_array($option['choices'])) foreach($option['choices'] as $id => $value) { 
$formsearch .= <<<EOF
                            <option value="{$id}" 
EOF;
 if($_GET['searchoption'][$optionid]['value'] == $id) { 
$formsearch .= <<<EOF
selected="selected"
EOF;
 } 
$formsearch .= <<<EOF
>{$value}</option>
                        
EOF;
 } 
$formsearch .= <<<EOF

                        </select>
                        <input type="hidden" name="searchoption[{$optionid}][type]" value="{$option['type']}">
                    
EOF;
 } else { 
$formsearch .= <<<EOF

                        
EOF;
 if(is_array($option['choices'])) foreach($option['choices'] as $id => $value) { 
$formsearch .= <<<EOF
                            <label><input type="checkbox" class="pc" name="searchoption[{$optionid}][value][{$id}]" value="{$id}" 
EOF;
 if(is_array($_GET['searchoption'][$optionid]) && $_GET['searchoption'][$optionid]['value'][$id]) { 
$formsearch .= <<<EOF
checked="checked"
EOF;
 } 
$formsearch .= <<<EOF
>{$value}</label>
                        
EOF;
 } 
$formsearch .= <<<EOF

                        <input type="hidden" name="searchoption[{$optionid}][type]" value="checkbox">
                    
EOF;
 } 
$formsearch .= <<<EOF

                    </span>
                
EOF;
 } else { 
$formsearch .= <<<EOF

                    
EOF;
 if($option['type'] == 'calendar') { 
$formsearch .= <<<EOF

                        <script src="{$_G['setting']['jspath']}calendar.js?{$__VERHASH}" type="text/javascript"></script>
                        <input type="text" name="searchoption[{$optionid}][value]" size="15" class="px vm" value="
EOF;
 if(is_array($_GET['searchoption'][$optionid])) { 
$formsearch .= <<<EOF
{$_GET['searchoption'][$optionid]['value']}
EOF;
 } 
$formsearch .= <<<EOF
" onclick="showcalendar(event, this, false)" />
                    
EOF;
 } else { 
$formsearch .= <<<EOF

                        <input type="text" name="searchoption[{$optionid}][value]" size="15" class="px vm" value="
EOF;
 if(is_array($_GET['searchoption'][$optionid])) { 
$formsearch .= <<<EOF
{$_GET['searchoption'][$optionid]['value']}
EOF;
 } 
$formsearch .= <<<EOF
" />
                    
EOF;
 } 
$formsearch .= <<<EOF

                
EOF;
 } 
$formsearch .= <<<EOF

            </div>
            
EOF;
?>
<?php } ?>
    <?php $formsearch_html .= $formsearch;?><?php $fontsearch = '';$showoption = array();$tmpcount = 0;?><?php if(getstatus($option['search'], 2)) { ?>
    <?php
$fontsearch = <<<EOF


<div class="bus_lineup"></div>
<li><a href="javascript:void(0)" style="background:#A9A9A9; color:#fff">{$option['title']}:</a></li>
                    <li
EOF;
 if($_GET[''.$option['identifier']] == 'all') { 
$fontsearch .= <<<EOF
 class="a"
EOF;
 } 
$fontsearch .= <<<EOF
><a href="forum.php?mod=forumdisplay&amp;fid={$_G['fid']}&amp;filter=sortid&amp;sortid={$_GET['sortid']}&amp;searchsort=1{$filterurladd}&amp;{$option['identifier']}=all{$sorturladdarray[$option['identifier']]}" class="xi2">����</a></li>

EOF;
 if($option['type'] == 'select') { if(is_array($option['choices'])) foreach($option['choices'] as $id => $value) { if($value['foptionid'] == 0) { 
$fontsearch .= <<<EOF

<li
EOF;
 if(preg_match('/^'.$value['optionid'].'\./i', $_GET[''.$option['identifier']]) || preg_match('/^'.$value['optionid'].'$/i', $_GET[''.$option['identifier']])) { 
$fontsearch .= <<<EOF
 class="a"
EOF;
 } 
$fontsearch .= <<<EOF
><a href="forum.php?mod=forumdisplay&amp;fid={$_G['fid']}&amp;filter=sortid&amp;sortid={$_GET['sortid']}&amp;searchsort=1&amp;{$option['identifier']}={$id}{$sorturladdarray[$option['identifier']]}" class="xi2">{$value['content']}</a></li>

EOF;
 } } if(!($_GET[''.$option['identifier']] == 'all' || !isset($_GET[''.$option['identifier']]))) { if(is_array($option['choices'])) foreach($option['choices'] as $id => $value) { if((preg_match('/^'.$value['foptionid'].'\./i', $_GET[''.$option['identifier']]) || preg_match('/^'.$value['foptionid'].'$/i', $_GET[''.$option['identifier']])) && ($showoption[$value['count']][$id] = $value)) { } } if(ksort($showoption)) { } if(is_array($showoption)) foreach($showoption as $optioncount => $values) { if($tmpcount != $optioncount && ($tmpcount = $optioncount)) { 
$fontsearch .= <<<EOF

</ul>
<div class="bus_lineup"></div>
<ul class="subtsm cl">
EOF;
 if(is_array($values)) foreach($values as $id => $value) { 
$fontsearch .= <<<EOF
<li
EOF;
 if(preg_match('/^'.$value['optionid'].'\./i', $_GET[''.$option['identifier']]) || preg_match('/^'.$value['optionid'].'$/i', $_GET[''.$option['identifier']])) { 
$fontsearch .= <<<EOF
 class="a"
EOF;
 } 
$fontsearch .= <<<EOF
><a href="forum.php?mod=forumdisplay&amp;fid={$_G['fid']}&amp;filter=sortid&amp;sortid={$_GET['sortid']}&amp;searchsort=1&amp;{$option['identifier']}={$id}{$sorturladdarray[$option['identifier']]}" class="xi2">{$value['content']}</a></li>

EOF;
 } 
$fontsearch .= <<<EOF

</ul><ul>

EOF;
 } } } } else { if(is_array($option['choices'])) foreach($option['choices'] as $id => $value) { 
$fontsearch .= <<<EOF
<li
EOF;
 if($_GET[''.$option['identifier']] && !strcmp($id, $_GET[''.$option['identifier']])) { 
$fontsearch .= <<<EOF
 class="a"
EOF;
 } 
$fontsearch .= <<<EOF
><a href="forum.php?mod=forumdisplay&amp;fid={$_G['fid']}&amp;filter=sortid&amp;sortid={$_GET['sortid']}&amp;searchsort=1&amp;{$option['identifier']}={$id}{$sorturladdarray[$option['identifier']]}" class="xi2">{$value}</a></li>

EOF;
 } } 
$fontsearch .= <<<EOF


EOF;
?>
     <?php } ?>
     <?php $fontsearch_html .= $fontsearch;?><?php } if($formsearch_html || $fontsearch_html) { ?>
<ul class="bus_sortb mt5 mb5">
<?php if($fontsearch_html) { ?>
    <div class="ptn">
    <table id="fontsearch" class="tsm cl">
         <?php echo $fontsearch_html;?>
    </table>
    </div>
<?php } if($formsearch_html) { ?>
    <form method="post" autocomplete="off" name="searhsort" id="searhsort" class="bbs bm_c pns mfm cl" action="forum.php?mod=forumdisplay&amp;fid=<?php echo $_G['fid'];?>&amp;filter=sortid&amp;sortid=<?php echo $_GET['sortid'];?>">
        <input type="hidden" name="formhash" value="<?php echo FORMHASH;?>" />
        <?php echo $formsearch_html;?>
        <div class="ptm cl"><button type="submit" class="pn pnc" name="searchsortsubmit"><em>����</em></button></div>
    </form>
<?php } ?>
</ul>
<?php } ?></div>
<?php } } ?>
<div class="clear"></div>

<?php if($_G['forum_threadcount']) { if(empty($_G['forum']['picstyle']) || $_G['cookie']['forumdefstyle']) { if(empty($_G['forum']['sortmode'])) { ?>
<div class="mobanbus_list bus_newslist pd10" id="newsBox">
<ul class="mobanbus_item mobanbus_scroll"><?php $listads = DB::result(DB::query("SELECT available FROM ".DB::table('common_advertisement')." WHERE `type`= 'threadlist'"));?><?php if(is_array($_G['forum_threadlist'])) foreach($_G['forum_threadlist'] as $key => $thread) { $tbid = DB::result(DB::query("SELECT tableid FROM ".DB::table('forum_attachment')." WHERE `tid`= '$thread[tid]'"));?><?php if($tbid) { $picount = DB::fetch_all("SELECT aid FROM ".DB::table('forum_attachment_'.$tbid.'')." WHERE `tid`= '$thread[tid]' AND `isimage`=1 LIMIT 0,3;");?><?php $picnum = count($picount);?><?php $covers = DB::fetch_all("SELECT attachment,aid,description FROM ".DB::table('forum_attachment_'.$tbid.'')." WHERE `tid`= '$thread[tid]' AND `isimage`=1 LIMIT 0,3;");?><li class="clt busload item fadeIn animated">
<?php if(!empty($_G['setting']['pluginhooks']['forumdisplay_thread_mobile'][$key])) echo $_G['setting']['pluginhooks']['forumdisplay_thread_mobile'][$key];?>
<div class="bus_newslist_txt">
<h2><a href="forum.php?mod=viewthread&amp;tid=<?php echo $thread['tid'];?>"><?php echo $thread['subject'];?></a>
<?php if($thread['price'] > 0) { ?>
<i class="icon_fufei">����</em></i>
<?php } if($thread['digest'] > 0) { ?>
<span class="icon_top">����</span>
<?php } if($thread['icon'] >= 0) { ?>
<span class="icon_tu"><?php echo $_G['cache']['stamps'][$thread['icon']]['text'];?></span>
<?php } if($thread['special'] == 1) { ?>
<span class="icon_tsy">ͶƱ</span>
<?php } elseif($thread['special'] == 2) { ?>
<span class="icon_tsy">��Ʒ</span>
<?php } elseif($thread['special'] == 3) { ?>
<span class="icon_tsy">����</span>
<?php } elseif($thread['special'] == 4) { ?>
<span class="icon_tsy">�</span>
<?php } elseif($thread['special'] == 5) { ?>
<span class="icon_tsy">����</span>
<?php } elseif(in_array($thread['displayorder'], array(1, 2, 3, 4))) { ?>
<span class="icon_tsy"><?php echo $_G['setting']['threadsticky'][3-$thread['displayorder']];?></span>
<?php } ?>
</h2>
</div>
<div class="clear"></div>
<div class="bus_pics">
<a href="forum.php?mod=viewthread&amp;tid=<?php echo $thread['tid'];?>&amp;<?php if($_GET['archiveid']) { ?>archiveid=<?php echo $_GET['archiveid'];?>&amp;<?php } ?>extra=<?php echo $extra;?>"<?php echo $thread['highlight'];?><?php if($thread['isgroup'] == 1 || $thread['forumstick']) { ?> target="_blank"<?php } else { ?> onclick="atarget(this)"<?php } ?>>

<?php if($picnum == 1) { if(is_array($covers)) foreach($covers as $thecover) { $imagelistkey = getforumimg($thecover[aid], 0, 600, 300);?><img src="template/mobanbus_motev1/mobile_st/img/5px.png" data-src="<?php echo $imagelistkey;?>" class="bus_pics_b"><?php } } else { if(is_array($covers)) foreach($covers as $thecover) { $imagelistkey = getforumimg($thecover[aid], 0, 250, 200);?><img src="template/mobanbus_motev1/mobile_st/img/5px.png" data-src="<?php echo $imagelistkey;?>" class="bus_pics_a"/><?php } } ?>
</a>
</div>
<div class="clear"></div>
<div class="bus_newslist_info">
<span class="bus_fl"><?php echo $thread['author'];?></span><span class="bus_fl"><?php echo $thread['views'];?> ���</span><span class="bus_fl"><?php echo $thread['replies'];?> ����</span><span class="bus_fl"><?php echo $thread['dateline'];?></span>
</div>
</li>

<?php } else { ?>

<li class="clt busload item fadeIn animated">
<?php if(!empty($_G['setting']['pluginhooks']['forumdisplay_thread_mobile'][$key])) echo $_G['setting']['pluginhooks']['forumdisplay_thread_mobile'][$key];?>
<div class="bus_newslist_txt">
<h2><a href="forum.php?mod=viewthread&amp;tid=<?php echo $thread['tid'];?>"><?php echo $thread['subject'];?></a>
<?php if($thread['price'] > 0) { ?>
<i class="icon_fufei"><em>����</em></i>
<?php } if($thread['digest'] > 0) { ?>
<span class="icon_top">����</span>
<?php } if($thread['icon'] >= 0) { ?>
<span class="icon_tu"><?php echo $_G['cache']['stamps'][$thread['icon']]['text'];?></span>
<?php } if($thread['special'] == 1) { ?>
<span class="icon_tsy">ͶƱ</span>
<?php } elseif($thread['special'] == 2) { ?>
<span class="icon_tsy">��Ʒ</span>
<?php } elseif($thread['special'] == 3) { ?>
<span class="icon_tsy">����</span>
<?php } elseif($thread['special'] == 4) { ?>
<span class="icon_tsy">�</span>
<?php } elseif($thread['special'] == 5) { ?>
<span class="icon_tsy">����</span>
<?php } elseif(in_array($thread['displayorder'], array(1, 2, 3, 4))) { ?>
<span class="icon_tsy"><?php echo $_G['setting']['threadsticky'][3-$thread['displayorder']];?></span>
<?php } ?>
</h2>
</div>
<div class="clear"></div>
<div class="bus_newslist_info">
<span class="bus_fl"><?php echo $thread['author'];?></span><span class="bus_fl"><?php echo $thread['views'];?> ���</span><span class="bus_fl"><?php echo $thread['replies'];?> ����</span><span class="bus_fl"><?php echo $thread['dateline'];?></span>
</div>
</li>

<?php } } ?>
</ul>
</div>
<?php } else { include template('forum/forumdisplay_sort'); } } else { ?>
<div class="bus_piclist"><?php if(is_array($_G['forum_threadlist'])) foreach($_G['forum_threadlist'] as $key => $thread) { if(!$_G['setting']['mobile']['mobiledisplayorder3'] && $thread['displayorder'] > 0) { continue;?><?php } ?>

<li class="clt busload busbox fadeIn animated">
<div class="bus_pics">
<a href="forum.php?mod=viewthread&amp;tid=<?php echo $thread['tid'];?>" class="preview">
<?php if($thread['attachment'] == 2) { $table='forum_attachment_'.substr($thread['tid'], -1);?><?php $thread['aid'] = DB::result_first("SELECT aid FROM ".DB::table($table)." WHERE tid='$thread[tid]' AND isimage!='0'");?><img src="template/mobanbus_motev1/mobanbus_st/img/busnomsg.jpg" data-src="<?php echo(getforumimg($thread['aid'],0,400,400))?>">
<?php } else { ?>
<img src="template/mobanbus_motev1/mobanbus_st/img/busnomsg.jpg">
<?php } ?>

</a>
<div class="bus_piclist_info">
<h2><a href="forum.php?mod=viewthread&amp;tid=<?php echo $thread['tid'];?>"><?php echo $thread['subject'];?></a></h2>
<div class="clear"></div>
<span class="bus_fl"><?php echo $thread['views'];?> ���</span>
</div>
</div>
</li>


<?php } ?>

</div>
<?php } ?>
<?php echo $multipage;?>
<?php } else { ?>
<li><span class="bus_noshow">������ָ���ķ�Χ����������<a href="forum.php?mod=post&amp;action=newthread&amp;fid=<?php echo $_G['fid'];?>&amp;mobile=2">����</a></span></li>
<?php } ?>


<!-- Mobanbus threadlist start -->
<?php if(!empty($_G['setting']['pluginhooks']['forumdisplay_bottom_mobile'])) echo $_G['setting']['pluginhooks']['forumdisplay_bottom_mobile'];?>
</div>
<!-- Mobanbus bus_w100 start --><?php $busrpnum = ceil(($_G[forum][threads]+1)/$_G['setting'][mobile][mobiletopicperpage]);?><script src="<?php echo $_G['siteurl'];?>template/mobanbus_motev1/mobile_st/js/mobanbus_lazy.js" type="text/javascript"></script><?php include template('common/footer'); ?>