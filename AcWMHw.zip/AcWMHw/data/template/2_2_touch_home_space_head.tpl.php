<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<!-- userinfo start -->
<div class="bus_userinfo">
<div class="user_cover">
<div class="busavatar">
<div class="avatar_m"><img src="<?php echo avatar($space[uid], middle, true);?>"></div>
<div class="user_info">
<div class="infotest">
<p><span><?php echo $space['threads'];?></span><em>������</em></p>
<p><span><?php echo $space['credits'];?></span><em>����</em></p>
<p><span><?php echo $space['friends'];?></span><em>������</em></p>
</div>
<div class="clear"></div>
</div>
</div>
<div class="clear"></div>

<?php if($space['self']) { ?>
<div class="bususertail">
<ul>
<li><a href="home.php?mod=space&amp;do=pm&amp;mobile=2">��Ϣ</a></li>
<li><a href="forum.php?mod=guide&amp;view=my&amp;type=reply">�ظ�</a></li>
<li><a href="home.php?mod=spacecp&amp;ac=profile">�༭</a></li>
<li><a href="member.php?mod=logging&amp;action=logout&amp;formhash=<?php echo FORMHASH;?>">�˳�</a></li>
</ul>
</div>
<?php } else { } ?>


