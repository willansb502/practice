<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); hookscriptoutput('guide');
0
|| checktplrefresh('./template/mobanbus_motev1/touch/forum/guide.htm', './template/mobanbus_motev1/touch/forum/guide_list_row.htm', 1654108040, '2', './data/template/2_2_touch_forum_guide.tpl.php', './template/mobanbus_motev1', 'touch/forum/guide')
;?><?php include template('common/header'); ?><div class="bus_spaceprofilenav">
<ul class="">
<li <?php if($view == 'new') { ?> class="a"<?php } ?>><a href="forum.php?mod=guide&amp;view=new">���»ظ�</a></li>
<li <?php if($view == 'hot') { ?> class="a"<?php } ?>><a href="forum.php?mod=guide&amp;view=hot">��������</a></li>
<li <?php if($view == 'digest') { ?> class="a"<?php } ?>><a href="forum.php?mod=guide&amp;view=digest">���¾���</a></li>
<li <?php if($view == 'my' && $viewtype=='reply') { ?> class="a"<?php } ?>><a href="forum.php?mod=guide&amp;view=my&amp;type=reply">�ҵ�����</a></li>
</ul>
</div>

<div class="bus_piclist busbox mt20">




<?php if($view == 'index') { if(is_array($data)) foreach($data as $key => $list) { ?> 		<?php if($list['threadcount']) { ?>
 <?php $i=0;?> <?php if(is_array($list['threadlist'])) foreach($list['threadlist'] as $thread) { ?> <?php $i++;$newtd=$i%2;?><li class="clt busload busbox fadeIn animated">
<div class="bus_pics">
<a href="forum.php?mod=viewthread&amp;tid=<?php echo $thread['tid'];?>" class="preview"><?php $busid = substr($thread[tid], -1); $cover = DB::result(DB::query("SELECT count(*) FROM ".DB::table('forum_attachment_'.$busid.'')." WHERE tid = '$thread[tid]' and isimage = '1'"));?><?php if($cover > 0) { $pics = DB::fetch_all("SELECT * FROM ".DB::table('forum_attachment_'.$busid.'')." WHERE `tid`= $thread[tid] ORDER BY `dateline` and isimage = '1' DESC limit 1");?><?php if(is_array($pics)) foreach($pics as $pic) { $imagelistkey = getforumimg($pic[aid], 0, 400, 400);?><img src="template/mobanbus_motev1/mobanbus_st/img/busnomsg.jpg" data-src="<?php echo $imagelistkey;?>">
<?php } } else { ?>
<img src="template/mobanbus_motev1/mobanbus_st/img/busnomsg.jpg">
<?php } ?>

</a>
<div class="bus_piclist_info">
<h2><a href="forum.php?mod=viewthread&amp;tid=<?php echo $thread['tid'];?>"><?php echo $thread['subject'];?></a></h2>
<div class="clear"></div>
<span class="bus_fl"><?php echo $thread['views'];?> 浏览</span>
</div>
</div>
</li>


 			<?php } ?>
 		<?php } else { ?>
 				<div class="busnomsg">��ʱ��û������</div>
 		<?php } } } else { if(is_array($data)) foreach($data as $key => $list) { if($list['threadcount']) { if(is_array($list['threadlist'])) foreach($list['threadlist'] as $key => $thread) { ?><li class="clt busload busbox fadeIn animated">
<div class="bus_pics">
<a href="forum.php?mod=viewthread&amp;tid=<?php echo $thread['tid'];?>" class="preview"><?php $busid = substr($thread[tid], -1); $cover = DB::result(DB::query("SELECT count(*) FROM ".DB::table('forum_attachment_'.$busid.'')." WHERE tid = '$thread[tid]' and isimage = '1'"));?><?php if($cover > 0) { $pics = DB::fetch_all("SELECT * FROM ".DB::table('forum_attachment_'.$busid.'')." WHERE `tid`= $thread[tid] ORDER BY `dateline` and isimage = '1' DESC limit 1");?><?php if(is_array($pics)) foreach($pics as $pic) { $imagelistkey = getforumimg($pic[aid], 0, 400, 400);?><img src="template/mobanbus_motev1/mobanbus_st/img/busnomsg.jpg" data-src="<?php echo $imagelistkey;?>">
<?php } } else { ?>
<img src="template/mobanbus_motev1/mobanbus_st/img/busnomsg.jpg">
<?php } ?>

</a>
<div class="bus_piclist_info">
<h2><a href="forum.php?mod=viewthread&amp;tid=<?php echo $thread['tid'];?>"><?php echo $thread['subject'];?></a></h2>
<div class="clear"></div>
<span class="bus_fl"><?php echo $thread['views'];?> ���</span>
</div>
</div>
</li>


<?php } } else { ?>
<div class="busnomsg">��ʱ��û������</div>
<?php } } ?>
<div class="clear"></div>
<?php echo $multipage;?>
<?php } ?>

</div>


</div>

<script src="<?php echo $_G['siteurl'];?>template/mobanbus_motev1/mobile_st/js/mobanbus_lazy.js" type="text/javascript"></script><?php include template('common/footer'); ?>