<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); hookscriptoutput('index');?><?php include template('common/header'); ?><link href="source/plugin/keke_group/template/css/pcstyle.css" rel="stylesheet" type="text/css">
<script src="source/plugin/keke_group/js/jquery.js" type="text/javascript"></script>
<script src="source/plugin/keke_group/js/jquery.qrcode.min.js" type="text/javascript"></script>
<script>jQuery.noConflict();</script>
<?php if($keke_group['pcleftcolour']) { ?><style>.sidebar li.active{ background:<?php echo $keke_group['pcleftcolour'];?> !important; }</style><?php } if($keke_group['pcbtncolour']) { ?><style>.btns{ background:<?php echo $keke_group['pcbtncolour'];?> !important; }</style><?php } ?>
<style>
#cardid {width: 380px;height: 32px;outline: 0;border: 1px solid #eee;text-align: center;border-radius: 1px;background: #fcfcfc; margin-left:20px; margin-top:20px;}
.cardpaybox{ display:none}
#cardid::placeholder{ color:#999}
.cardtxt{ padding:10px 0; color:#c3c3c3; margin-left:120px;}
.cardico {background: url(source/plugin/keke_group/template/images/pay_06.gif) left no-repeat;padding-left: 30px; background-size:18px;}
<?php if($alipayoff && $wxpayoff && $keke_group['cardid']) { ?>.chargebox .charge-source-list>li{ margin:5px 10px}<?php } ?>
</style>

<div class="keke_warning"></div>
<div class="wp guclearfix keke_group" >
        <div class="side">
            <ul class="sidebar">
                <?php if(file_exists('source/plugin/keke_wallet/keke_wallet.inc.php') && $_G['cache']['plugin']['keke_wallet']) { ?>
                <li <?php if($_GET['id']==keke_wallet) { ?>class="active"<?php } ?> style="border-bottom:5px solid #F5F5F5">
                <a href="plugin.php?id=keke_wallet">!lt002!</a>
                </li>
                <?php } ?>
                <?php if(file_exists('source/plugin/keke_chongzhi/keke_chongzhi.inc.php') && $_G['cache']['plugin']['keke_chongzhi']) { ?>
                <div class="kkbuycz">
                    <li <?php if((!$_GET['p']) && $_GET['id']=='keke_chongzhi') { ?>class="active"<?php } ?>>
                        <a href="plugin.php?id=keke_chongzhi"><?php if($chongzhipcleftbtntxt['0']) { ?><?php echo $chongzhipcleftbtntxt['0'];?><?php } else { ?>���ֳ�ֵ<?php } ?></a>
                    </li>
                    <li <?php if($_GET['p'] && $_GET['id']=='keke_chongzhi') { ?>class="active"<?php } ?> style="border-bottom:5px solid #F5F5F5">
                        <a href="plugin.php?id=keke_chongzhi&amp;p=my"><?php if($chongzhipcleftbtntxt['1']) { ?><?php echo $chongzhipcleftbtntxt['1'];?><?php } else { ?>��ֵ��¼<?php } ?></a>
                    </li>
                </div>
                <?php } ?>
                <?php if(file_exists('source/plugin/keke_tixian/keke_tixian.inc.php') && $_G['cache']['plugin']['keke_tixian']) { ?>
                 <div class="kkbuytx">
                    <li <?php if((!$_GET['p']) && $_GET['id']==keke_tixian) { ?>class="active"<?php } ?>>
                        <a href="plugin.php?id=keke_tixian">!langt36!</a>
                    </li>
                    <li <?php if($_GET['p'] && $_GET['id']==keke_tixian) { ?>class="active"<?php } ?> style="border-bottom:5px solid #F5F5F5">
                        <a href="plugin.php?id=keke_tixian&amp;p=my">!langt39!</a>
                    </li>
                </div>
                <?php } ?>
                
                <div class="kkbuygro">
                    <li <?php if(!$_GET['p']) { ?>class="active"<?php } ?>>
                        <a href="plugin.php?id=keke_group"><?php if($pcleftbtntxt['0']) { ?><?php echo $pcleftbtntxt['0'];?><?php } else { ?>�û��鹺��<?php } ?></a>
                    </li>
                    <li <?php if($_GET['p']=='my' && $_GET['id']=='keke_group') { ?>class="active"<?php } ?>>
                        <a href="plugin.php?id=keke_group&amp;p=my"><?php if($pcleftbtntxt['1']) { ?><?php echo $pcleftbtntxt['1'];?><?php } else { ?>�û��鹺���¼<?php } ?></a>
                    </li>
                    <li <?php if($_GET['p']=='sw' && $_GET['id']=='keke_group') { ?>class="active"<?php } ?> style="border-bottom:5px solid #F5F5F5">
                        <a href="plugin.php?id=keke_group&amp;p=sw"><?php if($pcleftbtntxt['2']) { ?><?php echo $pcleftbtntxt['2'];?><?php } else { ?>�û����л�<?php } ?></a>
                    </li>
                </div>
                <?php if(file_exists('source/plugin/keke_buyinvitecode/keke_buyinvitecode.inc.php') && $_G['cache']['plugin']['keke_buyinvitecode']) { ?>
                 <div class="kkbuytx">
                    <li <?php if((!$_GET['p']) && $_GET['id']==keke_buyinvitecode) { ?>class="active"<?php } ?>>
                        <a href="plugin.php?id=keke_buyinvitecode">�����빺��</a>
                    </li>
                </div>
                <?php } ?>
                
            </ul>
        </div>
        <div class="czmain guclearfix" >        
        <?php if($_GET['p']) { ?>
         <div class="groheader fix">
            <span class="uhead">
                <a href="home.php?mod=space&amp;uid=<?php echo $_G['uid'];?>">
                    <b class="relative">
                        <img class="head" src="<?php echo $_G['setting']['ucenterurl'];?>/avatar.php?uid=<?php echo $_G['uid'];?>&size=big">
                    </b>
                    <img class="hi" src="source/plugin/keke_group/template/images/hi.png">
                </a>
            </span>
            <a href="javascript:;" class="usnmae"><?php echo $_G['username'];?></a>
            <div>
                <ul class="flexBox">
                    <li><a href="home.php?mod=spacecp&amp;ac=usergroup"><span class="current">��ǰ�û��� [ <span style="color:#d36f16"><?php echo $nowgroup['title'];?></span> ]<?php if($nowgroup['overdue']) { ?><b style="font-weight:500; margin:0 10px; color:#CCC">&</b><span style="color:#C30;">�ѵ��ڣ������ѻ��л��û���</span><?php } ?></span></a></li>
                     <li style="margin-top:7px"><span class="currents">��Ч�� / <?php echo $nowgroup['time'];?> </span></li>
                </ul>
            </div>
        </div>
        <?php } ?> 
        	<?php if($_GET['p']==my) { ?>
            <div class="keke_mylist fix">
                <ul>
                    <?php if($list) { ?><?php echo $list;?><?php } else { ?><div class="noorder">�����κι����¼</div><?php } ?>
                </ul>
                <?php echo $multipage;?>
            </div>
            <?php } elseif($_GET['p']=='sw') { ?>
           
              <div class="swgroup">
                  <ul class="mygro">
                        <?php if($expirylist) { ?>
                        <?php if(is_array($expirylist)) foreach($expirylist as $keys => $vals) { ?>                        <li <?php if($n%2==0) { ?>class="sele"<?php } ?>>
                        <span class="rsw"><?php if($vals['type']=='ext') { ?><a href="plugin.php?id=keke_group" class="hightline">����</a><?php } if(!($_G['groupid']==$keys)) { if(!$vals['noswitch']) { ?><a href="javascript:" onclick="_group_switch('<?php echo $keys;?>')">�л�</a><?php } } ?></span>
                        <em class="groico"><img src="<?php if($vals['ico']) { ?><?php echo $vals['ico'];?><?php } else { ?>source/plugin/keke_group/template/images/ico7.png<?php } ?>" alt=""></em>
                        <div class="pup"> <?php echo $vals['grouptitle'];?> </div>
                        <div class="dow"> <?php if($vals['type']=='ext') { ?>��Ч���� / <?php echo $vals['time'];?><?php } else { ?>������Ч<?php } ?></div>
                        </li>
                        <?php $n++;?>                        <?php } ?>
                        <?php } else { ?>
                            <li class="noorder">���޿��л��û��飬��ǰ������ͨ<p style="margin-top:15px;"><a href="plugin.php?id=keke_group" class="btns">�����û���</a></p></li>
                        <?php } ?>
                    </ul>
              </div>
            <script>
function _group_switch(groupid){
var formhash='<?php echo FORMHASH;?>';
jQuery.get('<?php echo $_G['siteurl'];?>plugin.php?id=keke_group:swgro', {groupid:groupid,formhash:formhash},function (datas){
if(datas.state==1){
warning('�л��ɹ�',1);setTimeout(function() {window.location.reload();}, 2000);return false;
}else{
warning(datas.msg,2);
return false;
}
}, "json");
}
           
</script>
<?php } else { ?>
             <style>
            .givecredit{ position:absolute; right:-5px; top:-5px; padding:1px 8px;    background: linear-gradient(to right, #ff9966, #eb4c50); border-radius:12px; color:#FFF}
.givecredit img{ vertical-align:top; margin-top:2px;}
            </style>
            <form name="alipayment" action="plugin.php" method="get"  id="alipayment">
            <input type="hidden" name="id" value="keke_group:payapi" >
            <input type="hidden" name="formhash" value="<?php echo FORMHASH;?>" >
            <ul class="chargebox guclearfix" >
              <?php if($_G['cache']['plugin']['keke_market']) { ?>
             <div class="hotleft viptipbox sharebtns"><a href="javascript:void(0);"  onclick="showWindow('keke_market_share', 'plugin.php?id=keke_market:ajax&cid=<?php echo $course['id'];?>&formhash=<?php echo FORMHASH;?>&ac=pc_share&from=group');"><span class="iconfont " style="color:#fff">&#xe75e;</span><span class="" style="color:#fff"><?php echo $keke_market['pcsharetxt'];?></span></a></div><?php } ?>
            <?php if(is_array($gorupdata)) foreach($gorupdata as $key => $val) { ?>            <div class="service-list mr_35 <?php if($key==0) { ?>actives<?php } ?>"  data-money="<?php echo $val['money'];?>" data-time="<?php echo $val['time'];?>" data-buygroupid="<?php echo $val['id'];?>">
            	<?php if($val['givecradit']) { ?><div class="givecredit"><img src="source/plugin/keke_group/template/images/ico30.png" width="14"> ���� <?php echo $val['givecradit'];?>  <?php echo $_G['setting']['extcredits'][$val['givecredittype']]['title'];?></div><?php } ?>
            
                <em><img src="<?php echo $val['ico'];?>" alt=""></em>
                <div class="kekecent">
                <b><?php echo $val['groupname'];?></b>
                <p class="ms">&yen;<?php echo $val['money'];?>Ԫ / <?php if($val['time']) { ?>��Ч�� <?php echo $val['time'];?>��<?php } else { ?>������Ч<?php } ?></p>
                </div>
               	<div class="quanxian" style="display:none"><?php if(is_array($val['tequan'])) foreach($val['tequan'] as $tq) { ?><span class="keketq"><?php echo $tq;?></span><?php } ?></div>
           </div>
           <?php } ?>
           <input type="hidden" name="buygroupid" id="buygroupid" value="<?php echo $gorupdata['0']['id'];?>" >
              <div class="boxs">
                	<div class="gurow charge-source guclearfix" style=" border-bottom:1px dashed #eee; ">
                		<div class="subboxs">
                            <div class="label hg"> �����Ȩ</div>
                            <div class="czcontents line-height50">
                               <div class="quanxian" id="viewtq">
                                   <?php if(is_array($gorupdata['0']['tequan'])) foreach($gorupdata['0']['tequan'] as $tq) { ?><span class="keketq"><?php echo $tq;?></span><?php } ?>
                                 </div>
                            </div>
                        </div>
                    </div>
               		<div class="gurow charge-source guclearfix" style=" border-bottom:1px dashed #eee; ">
                
                		<div class="subboxs">
                            <div class="label jine"> Ӧ�����</div>
                            <div class="czcontent line-height50">
                                <span id="countNum"><?php echo $gorupdata['0']['money'];?></span>
                                Ԫ <b class="kkccc">/</b> <span class="cccs">��Ч�� : </span> <span id="validity"><?php if(!$gorupdata['0']['time']) { ?>������Ч<?php } else { ?><?php echo $gorupdata['0']['time'];?><?php } ?></span><span id="t" <?php if(!$gorupdata['0']['time']) { ?>style="display:none"<?php } ?>>��</span>
                            </div>
                        </div>
                    </div>
              		<div class="gurow charge-source guclearfix" style=" border-bottom:1px dashed #eee">
                        <div class="label zffs">
                            ֧����ʽ
                        </div>
                        <div class="czcontent">
                            <ul id="charge-source-list" class="charge-source-list clearfix" style="margin-bottom:15px;">
                            	<?php if($keke_group['payjsmchid'] && $keke_group['payjskey']) { ?>
                                 <li class="item kekeweixin <?php if($keke_group['defaultpaytype']==2) { ?>active<?php } ?>" source="2">
                                    <a href="javascript:void(0);">
                                        <img src="source/plugin/keke_group/template/images/pay_01.jpg">
                                    </a>
                                </li>
                                <?php } ?>
                                <?php if($keke_group['alipay']) { ?>
                                <li class="item alipay <?php if($keke_group['defaultpaytype']==1) { ?>active<?php } ?>" source="1">
                                    <a href="javascript:void(0);">
                                        <img src="source/plugin/keke_group/template/images/pay_02.jpg">
                                    </a>
                                </li>
                                <?php } ?>
                                <?php if($keke_group['cardid']) { ?>
                                 <li class="item kekecode <?php if($keke_group['defaultpaytype']==3) { ?>active<?php } ?>" source="3" >
                                    <a href="javascript:void(0);">
                                    <img src="source/plugin/keke_group/template/images/pay_03.png">
                                    </a>
                                </li>
                                <?php } ?>
                               
                            </ul>
                            <div id="ewm"></div>
                        </div>
                        <input type="hidden" name="zftype" id="zftype" value="<?php echo $keke_group['defaultpaytype'];?>">
                    </div>
         
                    <div class="cardpaybox" <?php if($keke_group['defaultpaytype']==3) { ?>style="display:block"<?php } ?>>
                        <div class="label cardico">֧������</div>
                        <div id="card">
                            <input type="text" name="cardid" id="cardid" placeholder="���ڴ˴���������֧������" autocomplete="off">
                        </div>
                        <div class="cardtxt">������ֵ������ڻ����Ӧ������������ֵ����ʵ��Ӧ����������ֲ����˻�</div>
                    </div>
                    
                    
                    <div class="gurow charge-submit guclearfix">
                        <div class="czcontent">
                            <a class="btns btn-submit" id="Submit" href="javascript:;">������ͨ</a>
                        </div>
                    </div>
                    <div class="czsmbox">
                    	<div class="czsm"><?php echo $keke_group['sm'];?></div>
                    </div>
              </div>
            </ul>
            
            </form>
            <script>
            jQuery(function() {
jQuery(".service-list").on("click", function() {
var that=jQuery(this);
                            that.siblings().removeClass("actives");
                            that.addClass("actives");
var money=that.attr("data-money"),
validity=that.attr("data-time"),
buygroupid=that.attr("data-buygroupid"),
tqs=that.children(".quanxian").html();
jQuery("#countNum").html(money);
if(validity==0){
jQuery("#validity").html('������Ч');
jQuery("#t").hide();
}else{
jQuery("#validity").html(validity);
jQuery("#t").show();
}
jQuery("#buygroupid").val(buygroupid);
jQuery("#viewtq").html(tqs);

                               
                        });

jQuery("#charge-source-list li").on("click", function() {
                            jQuery(this).siblings().removeClass("active");
                            jQuery(this).addClass("active");
                               
                               var source=jQuery(this).attr("source");
   
   if(source==3){
jQuery("#ewm").css("height","0px").hide().html('');
jQuery('.cardpaybox').show();
   }else{
                                    jQuery("#ewm").css("height","0px").show().html('');
jQuery('.cardpaybox').val('').hide();
jQuery('#cardid').val('');
   }

jQuery("#Submit").html('������ͨ');
                                jQuery("#zftype").attr("value",source);
                        });		

jQuery("#Submit").on("click", function() {
if(jQuery("#ewm").html()!=''){
//return false;
}
var uids='<?php echo $_G['uid'];?>';
if(uids<1){
warning('���½',2);
 setTimeout(function() {window.location.href='member.php?mod=logging&action=login';}, 4000);
return false;
}

                        var zftype=jQuery('#zftype').val();
                        if(!zftype){
                            return false;
                        }
                        
                        if(zftype==11){
                            jQuery('#alipayment').submit();
                        }else{
jQuery('#ewm').css("height","258px").html('<img src="source/plugin/keke_group/template/images/loading.gif" />');
                            jQuery.get('<?php echo $_G['siteurl'];?>plugin.php?id=keke_group:payapi', {
                                  zftype:zftype,buygroupid:jQuery("#buygroupid").val(),cardid:jQuery("#cardid").val(),time:new Date().getTime()
                            },function (data){
                                if(data.err){
jQuery('#ewm').css("height","0px").hide();
                                    warning(data.err,2);
                                }else if(data.ewmurl){
<?php if($keke_group['qr']==2) { ?>
jQuery('#ewm').html('<img src="'+data.ewmurl+'">');
<?php } else { ?>
jQuery('#ewm').html('').qrcode({width:200,height:200,correctLevel:0,text:data.ewmurl});
<?php } ?>
var orderid=data.orderid;
setInterval(function(){
jQuery.get('<?php echo $_G['siteurl'];?>plugin.php?id=keke_group:checkorder', {orderid:orderid,time:new Date().getTime()},function (datas){
if(datas.state==1){window.location.href = '<?php echo $returnurl;?>';return false;}else{return false;}
}, "json");
},2000); 
jQuery("#Submit").html('&#35831;&#20351;&#29992;&#25163;&#26426;&#25195;&#30721;&#25903;&#20184;');
                                }else if(data.cardok){
showDialog(data.cardok,'right', '', 'window.location.href = \'<?php echo $returnurl;?>\'',true,'','','','','',2);
                                }
                            }, "json");
                        }
                        });
});
</script>
         <?php } ?>
         <script>
            function warning(text,type){
var ico='ld.gif';
                if(type==1){
                    ico='ok.png';
                }else if(type==2){
                    ico='no.png';
                }
text='<img src="source/plugin/keke_group/template/images/'+ico+'"><br>'+text;
                jQuery('.keke_warning').show().html(text);
                if(type!=3){
                    setTimeout(function() {jQuery('.keke_warning').fadeOut();}, 3000);
                }
            }
</script>
        </div>
</div>
    
    <?php include template('common/footer'); ?>