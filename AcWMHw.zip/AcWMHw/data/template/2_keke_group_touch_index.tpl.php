<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<html>
<head>
        <meta http-equiv="Content-Type" content="text/html; charset=gb2312">
        <title><?php echo $title;?></title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
        <meta name="apple-mobile-web-app-capable" content="yes">
        <meta name="apple-touch-fullscreen" content="yes">
    	<script src="source/plugin/keke_group/js/jquery.js" type="text/javascript"></script>
        <script src="source/plugin/keke_group/js/jquery.qrcode.min.js" type="text/javascript"></script>
        <script src="source/plugin/keke_group/template/dist/js/jquery-weui.js" type="text/javascript" charset="UTF-8"></script>
<script src="source/plugin/keke_group/template/js/share.js?t=<?php echo TIMESTAMP;?>" type="text/javascript"></script>
<link rel="stylesheet" href="source/plugin/keke_group/template/dist/lib/weui.min.css">
<link rel="stylesheet" href="source/plugin/keke_group/template/dist/css/jquery-weui.css">
    	<link href="source/plugin/keke_group/template/css/wapstyle.css" rel="stylesheet" type="text/css">
        <?php if(K_INCWECHAT) { ?><script src="https://res.wx.qq.com/open/js/jweixin-1.0.0.js" type="text/javascript"></script><?php } ?>
        <script><?php if(K_INCWECHAT) { ?>
        wxshare('<?php if(K_INCWECHAT) { ?>1<?php } ?>','�û��鹺��','source/plugin/keke_group/template/images/share.png','<?php echo FORMHASH;?>','<?php if($_G['cache']['plugin']['keke_market']) { ?><?php echo $_G['siteurl'];?>plugin.php?id=keke_group&iuid=<?php echo $_G['uid'];?><?php } ?>');
        <?php } ?>
         </script>  
         <style>
         #cardid{display:inline-block; width:100%; font-size:16px; height:40px; line-height:40px; margin:15px 0 7px 0; text-align:center; background:#f9f9f9}
#cardid::placeholder{ color:#aeb1ae; line-height: 40px;}
.cardidboxs{ padding:15px 0; display:none}
.cardtip{ margin:5px 0; line-height:22px; color:#999; font-size:12px}
.cardtip a{color:#fc4e53 !important;}
<?php if($keke_group['rowtype']==2) { ?>
.service-list>.ct>b{ font-size:22px !important;}
.service-list{ height:100px; width:200px;  display:inline-block;float: left; padding:10px 0; margin-right:15px;}
.service-list:last-child{ margin-right:0}
.service-list em{ display:none}
.service-list .ct{ margin:5px auto; !important; width:100%; }
.service-list .ct b{text-align:center }
.service-list .givecredit{ position:absolute; top:-15px; right:0}
.service-list p.ms{ padding-top:3px !important;text-align:center}
.guclearfix{ padding:10px 15px 0 !important;}
.grouplist_box{  width: 100%;height: 136px;overflow: hidden;overflow-x: scroll; margin-top:10px}
.grouplist_subbox{ width:-webkit-max-content;width: -moz-max-content; width: max-content;overflow-x: scroll;position: relative;}
<?php } ?>
         </style>
</head>
<body style="background:#FFF">
<div class="keke_warning"></div>
 <form name="alipayment" action="plugin.php" method="get"  id="alipayment">
        <input type="hidden" name="id" value="keke_group:payapi" >
        <input type="hidden" name="formhash" value="<?php echo FORMHASH;?>" >
<div class="header fix">

<div class="headerbg" <?php if($keke_group['waptopcolour']) { ?>style=" background:<?php echo $keke_group['waptopcolour'];?>"<?php } ?>></div>
    <a href="./" class="chat" id="wapmysf_B01_05">
        <span class="replay-ico active"></span>
    </a>
    <span class="prove">
        <?php if($keke_group['backbtn']) { ?><a href="<?php if($keke_group['backurl']) { ?><?php echo $keke_group['backurl'];?><?php } else { ?>javascript:history.back(-1);<?php } ?>" class="back"></a><?php } ?>
    </span>
    <span class="myrec">
   		<?php if($_GET['p']==my) { ?><a href="plugin.php?id=keke_group">��ͨ</a><?php } else { ?><a href="plugin.php?id=keke_group&amp;p=my">��¼</a><?php } ?>
    </span>
     <span class="switchgro">
   		<a href="plugin.php?id=keke_group&amp;p=sw">�л�</a>
    </span>
    <span class="uhead">
        <a href="<?php if($_G['uid']) { ?>home.php?mod=space&uid=<?php echo $_G['uid'];?><?php } else { ?>member.php?mod=logging&action=login<?php } ?>">
            <b class="relative">
                <img class="head" src="<?php echo $_G['setting']['ucenterurl'];?>/avatar.php?uid=<?php echo $_G['uid'];?>&size=small">
            </b>
            <img class="hi" src="source/plugin/keke_group/template/images/hi.png">
        </a>
    </span>
    
    <?php if($_G['uid']) { ?><a href="home.php?mod=space&amp;uid=<?php echo $_G['uid'];?>" class="usnmae"><?php echo $_G['username'];?></a><?php } else { ?><a href="member.php?mod=logging&amp;action=login" class="usnmae">���½</a><?php } ?>
    <nav>
        <ul class="flexBox">
            <li><a href="home.php?mod=spacecp&amp;ac=usergroup"><span class="current">��ǰ�û��� [ <?php echo $nowgroup['title'];?> ]</span></a><?php if($nowgroup['overdue']) { ?><b style="font-weight:500; margin:0 5px;">&</b>�ѹ���<?php } ?></li>
             <li><span class="currents" style="font-size:12px; color:#fdcac8">��Ч�� / <?php echo $nowgroup['time'];?></span></li>
        </ul>
    </nav>
</div>
<?php if($_GET['p']==my) { ?>
<section class="mylist fix">
<nav>
    	<ul>
        	<?php if($list) { ?><?php echo $list;?><?php } else { ?><li class="nolist">�����κι����¼</li><?php } ?>
</ul>
        <?php echo $multipage;?>
    </nav>
</section>
<?php } elseif($_GET['p']=='sw') { ?>
<section class="mylist fix">
<nav>
   	  <ul class="mygro">
      		<?php if($expirylist) { ?>
      <?php if(is_array($expirylist)) foreach($expirylist as $keys => $vals) { ?>        	<li <?php if($n%2==0) { ?>class="sele"<?php } ?>>
                <span class="rsw"><?php if($vals['type']=='ext') { ?><a href="plugin.php?id=keke_group" class="hightline">����</a><?php } if(!($_G['groupid']==$keys)) { if(!$vals['noswitch']) { ?><a href="javascript:" onClick="_group_switch('<?php echo $keys;?>')">�л�</a><?php } } ?></span>
                <em class="groico"><img src="<?php if($vals['ico']) { ?><?php echo $vals['ico'];?><?php } else { ?>source/plugin/keke_group/template/images/ico7.png<?php } ?>" alt=""></em>
                <div class="pup"> <?php echo $vals['grouptitle'];?> </div>
                <div class="dow"> <?php if($vals['type']=='ext') { ?>��Ч���� / <?php echo $vals['time'];?><?php } else { ?>������Ч<?php } ?></div>
            </li>
            <?php $n++;?>            <?php } ?>
            <?php } else { ?>
            	<li class="nolist">���޿��л��û��飬��ǰ������ͨ<p style="margin-top:15px;"><a href="plugin.php?id=keke_group" class="btns">�����û���</a></p></li>
            <?php } ?>
</ul>
    </nav>
</section>

<script>	
function _group_switch(groupid){
var formhash='<?php echo FORMHASH;?>';
jQuery.get('<?php echo $_G['siteurl'];?>plugin.php?id=keke_group:swgro', {groupid:groupid,formhash:formhash},function (datas){
if(datas.state==1){
warning('�л��ɹ�',1);setTimeout(function() {window.location.reload();}, 2000);return false;
}else{
warning(datas.msg,2);
return false;
}
}, "json");
}

</script>

<?php } elseif($_GET['p']=='loading') { ?>
        <div class="loadings">
            <img src="source/plugin/keke_group/template/images/llls.gif" width="200"><p class="ldp">���ڵȴ�΢�ŷ�������Ӧ�����Ժ�...</p><p class="ldp">����ʱ������Ӧ����ϵ����Ա</p>
        </div>
        <script>
            var orderid='<?php echo $orderid;?>';
            setInterval(function(){
                jQuery.get('<?php echo $_G['siteurl'];?>plugin.php?id=keke_group:checkorder', {orderid:orderid},function (datas){
                    if(datas.state==1){window.location.href = '<?php echo $returnurl;?>';return false;}else{return false;}
                }, "json");
            },2000); 
        </script>
<?php } else { ?>

<style>
            .givecredit{ float:left; margin-bottom:5px; margin-top:5px;/*position:absolute; left:-1px; top:-10px;*/ padding:0px 10px 0px 7px;  background: linear-gradient(to right, #e45251, #ff8f8e); border-radius:2px; font-size:12px; color:#FFF}
.givecredit img{ vertical-align:top; margin-top:2px;}
            </style>

<section class="moneylist fix" style="margin-top:10px;">
<nav class="guclearfix"><div class="hg"> ��Ա���� </div>
    	<div class="grouplist_box">
        <div class="grouplist_subbox fix">
    <?php if(is_array($gorupdata)) foreach($gorupdata as $key => $val) { ?>            <div class="service-list mr_35 <?php if($key==0) { ?>actives<?php } ?>"  data-money="<?php echo $val['money'];?>" data-time="<?php echo $val['time'];?>" data-buygroupid="<?php echo $val['id'];?>">
                <em><img src="<?php echo $val['ico'];?>" alt=""></em>
                <div class="ct" <?php if($val['givecradit']) { ?> style="margin-top:5px"<?php } ?>>
                <b><?php echo $val['groupname'];?></b>
                <p class="ms" <?php if($val['givecradit']) { ?> style="margin-top:0px; padding-top:0"<?php } ?>>&yen; <?php echo $val['money'];?>Ԫ / <?php if($val['time']) { ?>��Ч�� <?php echo $val['time'];?>��<?php } else { ?>������Ч<?php } ?></p>
                
                <?php if($val['givecradit']) { ?><div class="givecredit"><img src="source/plugin/keke_group/template/images/ico30.png" width="14"> ���� <?php echo $val['givecradit'];?> <?php echo $_G['setting']['extcredits'][$val['givecredittype']]['title'];?></div><?php } ?>
                
                </div>
               	<div class="quanxian" style="display:none"><?php if(is_array($val['tequan'])) foreach($val['tequan'] as $tq) { ?><span class="tq"><?php echo $tq;?></span><?php } ?></div>
           </div>
         <?php } ?>
         </div>
         </div>
</nav>
</section>
<input type="hidden" name="buygroupid" id="buygroupid" value="<?php echo $gorupdata['0']['id'];?>" >
<section class="fix subboxs" style=" padding:0px 15px 20px 15px; margin-top:20px;   ">
        <div class="subbox">
            <div class="hg"> �����Ȩ</div>
            <div class="czcontents" style="line-height:50px">
               <div class="quanxian" id="viewtq">
                   <?php if(is_array($gorupdata['0']['tequan'])) foreach($gorupdata['0']['tequan'] as $tq) { ?><span class="tq"><?php echo $tq;?></span><?php } ?>
                 </div>
            </div>
        </div>
</section>

<section class="pays fix " style=" padding-top:0px; margin-top:0px;    border-top: 10px solid #f4f4f4;">
<style>
    .weui-cell{ padding:10px 0}
.weui-cells:before,.weui-cells:after{ border:0}
.weui-cell__hd{ margin-right:15px;}
.weui-cells_radio .weui-check:checked+.weui-icon-checked:before{ color:#F00}
    </style>
    <div class="weui-cells weui-cells_radio">
    <?php if($keke_group['payjsmchid'] && $keke_group['payjskey']) { ?>
      <label class="weui-cell weui-check__label" for="x12">
      	<div class="weui-cell__hd"><img src="source/plugin/keke_group/template/images/pay_05.png" width="45"></div>
        <div class="weui-cell__bd payinfo">
          <p>΢��֧��</p>
            <span>�Ƽ���΢���˻����û�ʹ��</span>
        </div>
        <div class="weui-cell__ft">
          <input type="radio" name="zftype" value="2" class="weui-check" id="x12"  <?php if($keke_group['defaultpaytype']==2) { ?>checked="checked"<?php } ?>>
          <span class="weui-icon-checked"></span>
        </div>
      </label>
      <?php } ?>
      <?php if($keke_group['alipay']) { ?>
      <label class="weui-cell weui-check__label" for="x11">
      	<div class="weui-cell__hd"><img src="source/plugin/keke_group/template/images/pay_04.png" width="45"></div>
        <div class="weui-cell__bd payinfo">
          	<p>֧����֧��</p>
            <span>�Ƽ���֧�����˻����û�ʹ��</span>
        </div>
        <div class="weui-cell__ft">
          <input type="radio" name="zftype" value="1" class="weui-check" name="radio1" id="x11" <?php if($keke_group['defaultpaytype']==1) { ?>checked="checked"<?php } ?>>
          <span class="weui-icon-checked"></span>
        </div>
      </label>
      <?php } ?>
      
     <?php if($keke_group['cardid']) { ?> 
      <label class="weui-cell weui-check__label" for="x13">
      	<div class="weui-cell__hd"><img src="source/plugin/keke_group/template/images/pay_06.gif" width="45"></div>
        <div class="weui-cell__bd payinfo">
          <p>����֧��</p>
            <span>ʹ�ÿ��ܽ���֧��</span>
        </div>
        <div class="weui-cell__ft">
          <input type="radio" name="zftype" value="3" class="weui-check" id="x13" <?php if($keke_group['defaultpaytype']==3) { ?>checked="checked"<?php } ?>>
          <span class="weui-icon-checked"></span>
        </div>
      </label>
      <?php } ?>
    </div>
    
    <div id="ewm"> </div>
    <div class="cardidboxs" <?php if($keke_group['cardid'] && $keke_group['defaultpaytype']==3) { ?>style="display:block"<?php } ?>> 
    <input type="text" placeholder="���ڴ˴���������֧������" name="cardid" id="cardid" >
    <div class="cardtip">������ֵ������ڻ����Ӧ������������ֵ����ʵ��Ӧ����������ֲ����˻�</div>
    </div>
    
</section>

<div class="mm-btn" id="btn"><a href="javascript:void(0);" id="Submit">������ͨ</a></div>
</form>


<div class="czsmbox">
    <div class="czsm"><?php echo $keke_group['sm'];?></div>
</div>



<?php if($_G['cache']['plugin']['keke_market'] && $keke_group['share']) { include template('keke_market:market_block'); } ?>


<script>
jQuery(function() {
var zjdtis=jQuery("#zjdtis");
var recharge=jQuery("#recharge");
var moneyQuantity=jQuery("#moneyQuantity");
jQuery("input[name=zftype]").on("click", function() {
var zftypes=jQuery(this).val();
if(zftypes==3){
jQuery("#ewm").text('').hide();
jQuery(".cardidboxs").show();
}else{
jQuery("#ewm").text('').show();
jQuery(".cardidboxs").hide();
};

});
jQuery(".service-list").on("click", function() {
var that=jQuery(this);
that.siblings().removeClass("actives");
that.addClass("actives");
var money=that.attr("data-money"),
validity=that.attr("data-time"),
buygroupid=that.attr("data-buygroupid"),
tqs=that.children(".quanxian").html();
jQuery("#countNum").html(money);
jQuery("#validity").html(validity);
jQuery("#buygroupid").val(buygroupid);
jQuery("#viewtq").html(tqs);
});

jQuery(".moneylist li").on("click", function() {
jQuery(this).siblings().removeClass("on");
jQuery(this).addClass("on");
var nn=jQuery(this).hasClass("zdy");
if(nn){
zjdtis.hide();
recharge.show();
moneyQuantity.attr("value","");
}else{
zjdtis.show();
recharge.hide();
var money=jQuery(this).attr("money");
moneyQuantity.attr("value",money);
};

});

jQuery("#Submit").on("click", function() {

var zftype=jQuery('input:radio[name="zftype"]:checked').val();
if(!zftype){
return false;
}
var uids='<?php echo $_G['uid'];?>';
if(uids<1){
warning('���½',2);
 setTimeout(function() {window.location.href='<?php echo $_G['siteurl'];?>member.php?mod=logging&action=login&mobile=2&referer=<?php echo $_G['siteurl'];?>plugin.php?id=keke_group';}, 4000);
return false;
}
$.showLoading();
jQuery.get('<?php echo $_G['siteurl'];?>plugin.php?id=keke_group:payapi', {
 zftype:zftype,buygroupid:jQuery("#buygroupid").val(),cardid:jQuery("#cardid").val()
},function (data){
 $.hideLoading();
if(data.err){
warning(data.err,2);
}else if(data.cardok){
warning(data.cardok,1);
setTimeout(function() {window.location.href='<?php echo $returnurl;?>';}, 2000);
}else if(data.ewmurl){
var tip='�뱣���ά�뵽֧����֧��';
if(zftype==2){
tip='�뱣���ά�뵽΢��֧��';
}
$.modal({
  title: tip,
  text: "<img src='" + data.ewmurl + "' />",
  buttons: [
{ text: "�ر�", className: "default"},
  ]
});					
}else if(data.payjsurl){
window.location.href=data.payjsurl; 
}
}, "json");

});
});


</script>
<?php } ?>
 <script>
  function warning(text,type){
  var ico='ld.gif';
  if(type==1){
  ico='ok.png';
  }else if(type==2){
  ico='no.png';
  }
  text='<img src="source/plugin/keke_group/template/images/'+ico+'"><br>'+text;
  jQuery('.keke_warning').show().html(text);
  if(type!=3){
  setTimeout(function() {jQuery('.keke_warning').fadeOut();}, 3000);
  }
  }
  </script>
</body></html>