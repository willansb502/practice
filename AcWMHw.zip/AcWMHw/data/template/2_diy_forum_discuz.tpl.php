<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); hookscriptoutput('discuz');
block_get('10,11,12,13,14');?><?php include template('common/header'); ?><?php if(!empty($_G['setting']['pluginhooks']['index_status_extra'])) echo $_G['setting']['pluginhooks']['index_status_extra'];?>

<?php if(empty($gid)) { ?><?php echo adshow("text/wp a_t");?><?php } ?>
<style id="diy_style" type="text/css"></style>

<div class="wp">
<div class="clear"></div>

<script src="template/mobanbus_motev1/mobanbus_st/js/froumslide.js" type="text/javascript"></script>
<style type="text/css">

.frame-title, .frametitle, .tab-title .frame-title, .frametitle, .tab-title {
    background: #ffffff;
}
.tb a {
    display: block;
    padding: 0 10px;
border: 0px solid #CDCDCD;
}
.deanwp,.wp{ width:100%;}
#ct{ margin:0 auto; width:1380px!important;}
.deanboxone{ width:1380px; margin:0 auto;}
.frame-tab .tb .a a {
    background: #FD2063;
    font-weight: 700;
    color: #ffffff;
}
.frame-tab .tb li {
    margin: 0;
    margin-left: 10px;
    font-weight: 400;
}
.frame-tab .tb li, .frame-tab .tb li a {
    -moz-border-radius: 0;
    -webkit-border-radius: 0;
    border-radius: 0;
    border-top: none;
    background: #f1f1f1;
}
.deandzwpbox{ width:1380px; margin:0 auto; height:340px; margin-top:15px; margin-bottom:15px; }
.deandzwp{ width:100%; }
.deandzwpl{ width:500px; float:left;}
.deandzwpr{ width:860px; float:right;}
.deandztab{ width:860px;}
.deandztabname{}
.deandztabname li{ float:left; height:30px; line-height:30px; color:#666; background:#f1f1f1; margin-right:10px; font-size:12px; cursor:pointer; padding:0 15px;}
.deandztabname li.cur{  background:#FD2063; color:#fff; }
.deandztabc{ margin-top:10px;}
.deanzphot{ padding-bottom:10px; margin-bottom:10px; border-bottom:1px dashed #e6e6e6;}
.deanzphot span{ display:block; width:32px; height:49px; line-height:49px; font-size:20px; font-weight:bold; float:left; overflow:hidden; text-align:center; color:#fff; background:#FD2063;}
.deanzphotr{ float:right; width:780px;}
.deanzphotr a{ font-size:18px; color:#FD2063;}
.deanzphotr a:hover{ text-decoration:underline;}
.deanzphots{ font-size:14px; color:#999; font-size:12px; line-height:25px;}
.deandztabc li{ display:none;}
.deandztabc li dl{}
.deandztabc li dl dd{ display:block; clear:both; font-size:12px; color:#666; height:32px; line-height:32px;}
.deandztabc li dl dd span{ width:20px; height:20px; display:block; float:left; text-align:center; line-height:22px; color:#fff; font-size:12px; margin-top:6px; margin-right:15px; background:#ccc;}
.deantabdd1 span{background:#FD2063; }
.deantabdd2 span{background:#98CE1E; }
.deantabdd3 span{background:#FFCC00; }
.deantabdd4 span{background:#ccc; }
.deantabdd5 span{background:#ccc; }
.deantabdd6 span{background:#ccc; }
.deantabdd7 span{background:#ccc; }
.deantabdd8 span{background:#ccc; }
.deandztabc li dl dd a{ float:left; font-size:14px; color:#333;}
.deantabdd1 a{ color:#FD2063; }
.deantabdd2 a{ color:#98CE1E; }
.deantabdd3 a{ color:#FFCC00;}
.deandztabc li dl dd a:hover{ color:#FD2063;}
.deandztabc li dl dd em{ float:left; padding-left:5px; color:#a8a8a8;}
.deandztabci{ float:right; color:#a8a8a8;} 
/*�õ�Ƭ*/
.picbox{width:500px; ;}
#featured{height:290px;overflow:hidden;position:relative;}
#featured .image{position:absolute;height:290px;overflow:hidden;}
#featured .word{z-index:10; left:0px; bottom:0px;  width:500px; position:absolute;height:103px; background:url(<?php echo STYLEIMGDIR;?>/portal/bg.png) 0 0 repeat-x;}
#featured .word h3{font-size:16px; height:30px; line-height:30px; font-weight:400; width:460px; position:absolute; left:20px; bottom:10px;}
#featured .word h3 a{ color:#fff;}
#featured .word p{line-height:22px; color:#eee; font-size:12px; font-family:Arial, Helvetica, sans-serif;  padding-left:10px;}
#thumbs{width:500px;height:57px; }
*html #thumbs{height:100%;}
#thumbs li{display:inline;float:left;cursor:pointer}
#thumbs li a{display:block;font-size:0px; width:75px;height:37px;padding:10px; padding-left:0;}
#thumbs li a#thumb_pic-06{ padding-right:0!important;}
#thumbs li a img{display:block;font-size:0px;width:72px;height:35px;border:2px solid #e6e6e6; opacity:0.45;}
#thumbs li a:hover img{display:block;border:2px solid #FD2063; height:35px;width:72px; opacity:1;}
#thumbs li a.current img{display:block;border:2px solid #FD2063; height:35px;width:72px; opacity:1;}
</style>
<div class="deandzwp" style="width:100%;">
<div class="deandzwpbox">
        <div class="deandzwpl"><!--[diy=deandzwpl]--><div id="deandzwpl" class="area"><div id="frame99g8yI" class="cl_frame_bm frame move-span cl frame-1"><div id="frame99g8yI_left" class="column frame-1-c"><div id="frame99g8yI_left_temp" class="move-span temp"></div><?php block_display('10');?></div></div></div><!--[/diy]--></div>
        <div class="deandzwpr">
        	<div class="deandztab">
                    <dl><!--[diy=deandztabc3]--><div id="deandztabc3" class="area"><div id="tab9VhdOE" class="cl_frame_bm frame-tab move-span cl"><div id="tab9VhdOE_title" class="tab-title title column cl" switchtype="mouseover"><?php block_display('11');?><?php block_display('12');?><?php block_display('13');?><?php block_display('14');?></div><div id="tab9VhdOE_content" class="tb-c"></div><script type="text/javascript">initTab("tab9VhdOE","mouseover");</script></div></div><!--[/diy]--></dl>
            	            </div>
        </div>
      <div class="clear"></div>
    </div>
</div>


<div class="bus_adss">
<!--[diy=diy_bus_adsss]--><div id="diy_bus_adsss" class="area"></div><!--[/diy]-->
</div>
<div class="clear"></div>
<div id="ct" class="wp cl<?php if($_G['setting']['forumallowside']) { ?> ct2<?php } ?>">























  <?php if(empty($gid)) { ?>
  <div id="chart" class="bm bw0 cl">
    <p class="chart z">����: <em><?php echo $todayposts;?></em><span class="pipe">|</span>����: <em><?php echo $postdata['0'];?></em><span class="pipe">|</span>����: <em><?php echo $posts;?></em><span class="pipe">|</span>��Ա: <em><?php echo $_G['cache']['userstats']['totalmembers'];?></em>
      <?php if($_G['cache']['userstats']['newsetuser']) { ?>
      <span class="pipe">|</span>��ӭ�»�Ա: <em><a href="home.php?mod=space&amp;username=<?php echo rawurlencode($_G['cache']['userstats']['newsetuser']); ?>" target="_blank" class="xi2"><?php echo $_G['cache']['userstats']['newsetuser'];?></a></em>
      <?php } ?>
    </p>
    <div class="y">
      <?php if(!empty($_G['setting']['pluginhooks']['index_nav_extra'])) echo $_G['setting']['pluginhooks']['index_nav_extra'];?>
      <?php if($_G['uid']) { ?>
      <a href="forum.php?mod=guide&amp;view=my" title="�ҵ�����" class="xi2">�ҵ�����</a>
      <?php } ?>
      <?php if(!empty($_G['setting']['search']['forum']['status'])) { ?>
      <?php if($_G['uid']) { ?>
      <span class="pipe">|</span>
      <?php } ?>
      <a href="forum.php?mod=guide&amp;view=new" title="���»ظ�" class="xi2">���»ظ�</a>
      <?php } ?>
    </div>
  </div>
  <?php } ?>
  <!--[diy=diy_chart]--><div id="diy_chart" class="area"></div><!--[/diy]-->
  <div class="mn" style="width:100%;">
  <?php if(!empty($_G['setting']['pluginhooks']['index_favforum_extra'][$forum[fid]])) echo $_G['setting']['pluginhooks']['index_favforum_extra'][$forum[fid]];?>
  <?php if(!empty($_G['setting']['pluginhooks']['index_favforum_extra'][$forum[fid]])) echo $_G['setting']['pluginhooks']['index_favforum_extra'][$forum[fid]];?>
    <?php if(!empty($_G['setting']['grid']['showgrid'])) { ?>
    <!-- index four grid -->
    <div class="fl bm">
      <div class="bm bmw cl bus_box">
        <div id="category_grid" class="bm_c" >
          <table cellspacing="0" cellpadding="0">
            <tr>
              <?php if(!$_G['setting']['grid']['gridtype']) { ?>
              <td valign="top" class="category_l1"><div class="newimgbox">
                  <h4><span class="tit_newimg"></span>����ͼƬ</h4>
                  <div class="module cl slidebox_grid" style="width:218px">
                    <script type="text/javascript">
                  var slideSpeed = 5000;
                  var slideImgsize = [218,200];
                  var slideBorderColor = '<?php echo $_G['style']['specialborder'];?>';
                  var slideBgColor = '<?php echo $_G['style']['commonbg'];?>';
                  var slideImgs = new Array();
                  var slideImgLinks = new Array();
                  var slideImgTexts = new Array();
                  var slideSwitchColor = '<?php echo $_G['style']['tabletext'];?>';
                  var slideSwitchbgColor = '<?php echo $_G['style']['commonbg'];?>';
                  var slideSwitchHiColor = '<?php echo $_G['style']['specialborder'];?>';
                  <?php $k = 1;?>                  <?php if(is_array($grids['slide'])) foreach($grids['slide'] as $stid => $svalue) { ?>                    slideImgs[<?php echo $k; ?>] = '<?php echo $svalue['image'];?>';
                    slideImgLinks[<?php echo $k; ?>] = '<?php echo $svalue['url'];?>';
                    slideImgTexts[<?php echo $k; ?>] = '<?php echo $svalue['subject'];?>';
                    <?php $k++;?>                  <?php } ?>
                  </script>
                    <script src="<?php echo $_G['setting']['jspath'];?>forum_slide.js?<?php echo VERHASH;?>" type="text/javascript"></script>
                  </div>
                </div></td>
              <?php } ?>
              <td valign="top" class="category_l2"><div class="subjectbox">
                  <h4><span class="tit_subject"></span>��������</h4>
                  <ul class="category_newlist">
                    <?php if(is_array($grids['newthread'])) foreach($grids['newthread'] as $thread) { ?>                    <?php if(!$thread['forumstick'] && $thread['closed'] > 1 && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])) { ?>
                    <?php $thread[tid]=$thread[closed];?>                    <?php } ?>
                    <li><a href="forum.php?mod=viewthread&amp;tid=<?php echo $thread['tid'];?>&amp;extra=<?php echo $extra;?>"<?php if($thread['highlight']) { ?> <?php echo $thread['highlight'];?><?php } if($_G['setting']['grid']['showtips']) { ?> tip="����: <strong><?php echo $thread['oldsubject'];?></strong><br/>����: <?php echo $thread['author'];?> (<?php echo $thread['dateline'];?>)<br/>�鿴/�ظ�: <?php echo $thread['views'];?>/<?php echo $thread['replies'];?>" onmouseover="showTip(this)"<?php } else { ?> title="<?php echo $thread['oldsubject'];?>"<?php } if($_G['setting']['grid']['targetblank']) { ?> target="_blank"<?php } ?>><?php echo $thread['subject'];?></a></li>
                    <?php } ?>
                  </ul>
                </div></td>
              <td valign="top" class="category_l3"><div class="replaybox">
                  <h4><span class="tit_replay"></span>���»ظ�</h4>
                  <ul class="category_newlist">
                    <?php if(is_array($grids['newreply'])) foreach($grids['newreply'] as $thread) { ?>                    <?php if(!$thread['forumstick'] && $thread['closed'] > 1 && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])) { ?>
                    <?php $thread[tid]=$thread[closed];?>                    <?php } ?>
                    <li><a href="forum.php?mod=redirect&amp;tid=<?php echo $thread['tid'];?>&amp;goto=lastpost#lastpost"<?php if($thread['highlight']) { ?> <?php echo $thread['highlight'];?><?php } if($_G['setting']['grid']['showtips']) { ?>tip="����: <strong><?php echo $thread['oldsubject'];?></strong><br/>����: <?php echo $thread['author'];?> (<?php echo $thread['dateline'];?>)<br/>�鿴/�ظ�: <?php echo $thread['views'];?>/<?php echo $thread['replies'];?>" onmouseover="showTip(this)"<?php } else { ?> title="<?php echo $thread['oldsubject'];?>"<?php } if($_G['setting']['grid']['targetblank']) { ?> target="_blank"<?php } ?>><?php echo $thread['subject'];?></a></li>
                    <?php } ?>
                  </ul>
                </div></td>
              <td valign="top" class="category_l3"><div class="hottiebox">
                  <h4><span class="tit_hottie"></span>����</h4>
                  <ul class="category_newlist">
                    <?php if(is_array($grids['hot'])) foreach($grids['hot'] as $thread) { ?>                    <?php if(!$thread['forumstick'] && $thread['closed'] > 1 && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])) { ?>
                    <?php $thread[tid]=$thread[closed];?>                    <?php } ?>
                    <li><a href="forum.php?mod=viewthread&amp;tid=<?php echo $thread['tid'];?>&amp;extra=<?php echo $extra;?>"<?php if($thread['highlight']) { ?> <?php echo $thread['highlight'];?><?php } if($_G['setting']['grid']['showtips']) { ?> tip="����: <strong><?php echo $thread['oldsubject'];?></strong><br/>����: <?php echo $thread['author'];?> (<?php echo $thread['dateline'];?>)<br/>�鿴/�ظ�: <?php echo $thread['views'];?>/<?php echo $thread['replies'];?>" onmouseover="showTip(this)"<?php } else { ?> title="<?php echo $thread['oldsubject'];?>"<?php } if($_G['setting']['grid']['targetblank']) { ?> target="_blank"<?php } ?>><?php echo $thread['subject'];?></a></li>
                    <?php } ?>
                  </ul>
                </div></td>
              <?php if($_G['setting']['grid']['gridtype']) { ?>
              <td valign="top" class="category_l4"><div class="goodtiebox">
                  <h4><span class="tit_goodtie"></span>��������</h4>
                  <ul class="category_newlist">
                    <?php if(is_array($grids['digest'])) foreach($grids['digest'] as $thread) { ?>                    <?php if(!$thread['forumstick'] && $thread['closed'] > 1 && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])) { ?>
                    <?php $thread[tid]=$thread[closed];?>                    <?php } ?>
                    <li><a href="forum.php?mod=viewthread&amp;tid=<?php echo $thread['tid'];?>&amp;extra=<?php echo $extra;?>"<?php if($thread['highlight']) { ?> <?php echo $thread['highlight'];?><?php } if($_G['setting']['grid']['showtips']) { ?> tip="����: <strong><?php echo $thread['oldsubject'];?></strong><br/>����: <?php echo $thread['author'];?> (<?php echo $thread['dateline'];?>)<br/>�鿴/�ظ�: <?php echo $thread['views'];?>/<?php echo $thread['replies'];?>" onmouseover="showTip(this)"<?php } else { ?> title="<?php echo $thread['oldsubject'];?>"<?php } if($_G['setting']['grid']['targetblank']) { ?> target="_blank"<?php } ?>><?php echo $thread['subject'];?></a></li>
                    <?php } ?>
                  </ul>
                </div></td>
              <?php } ?>
          </table>
        </div>
      </div>
    </div>
    <!-- index four grid end -->
    <?php } ?>
    <?php if(!empty($_G['setting']['pluginhooks']['index_top'])) echo $_G['setting']['pluginhooks']['index_top'];?>

    <?php if(!empty($_G['setting']['pluginhooks']['index_catlist_top'])) echo $_G['setting']['pluginhooks']['index_catlist_top'];?>
    <div class="fl bm">
      <?php if(!empty($collectiondata['follows'])) { ?>
      <?php $forumscount = count($collectiondata['follows']);?>      <?php $forumcolumns = 4;?>      <?php $forumcolwidth = (floor(100 / $forumcolumns) - 0.1).'%';?>      <div class="bm bmw <?php if($forumcolumns) { ?> flg<?php } ?> cl bus_box busbb">
        <div class="bm_h cl"> <span class="o"> <img id="category_-1_img" src="<?php echo IMGDIR;?>/<?php echo $collapse['collapseimg_-1'];?>" title="����/չ��" alt="����/չ��" onclick="toggle_collapse('category_-1');" /> </span>
          <h2 class="tt"><a href="forum.php?mod=collection&amp;op=my">�Ҷ��ĵ�ר��</a></h2>
        </div>
        <div id="category_-1" class="bm_c" style="<?php echo $collapse['category_-1']; ?>">
          <table cellspacing="0" cellpadding="0" class="fl_tb">
            <tr>
              <?php $ctorderid = 0;?>              <?php if(is_array($collectiondata['follows'])) foreach($collectiondata['follows'] as $key => $colletion) { ?>              <?php if($ctorderid && ($ctorderid % $forumcolumns == 0)) { ?>
            </tr>
            <?php if($ctorderid < $forumscount) { ?>
            <tr class="fl_row">
              <?php } ?>
              <?php } ?>
              <td class="fl_g"<?php if($forumcolwidth) { ?> width="25%"<?php } ?>><div class="fl_icn_g"> <a href="forum.php?mod=collection&amp;action=view&amp;ctid=<?php echo $colletion['ctid'];?>" target="_blank"><img src="<?php echo $_G['style']['styleimgdir'];?>/forum<?php if($followcollections[$key]['lastvisit'] < $colletion['lastupdate']) { ?>_new<?php } ?>.gif" alt="<?php echo $colletion['name'];?>" /></a> </div>
                <dl>
                  <dt><a href="forum.php?mod=collection&amp;action=view&amp;ctid=<?php echo $colletion['ctid'];?>"><?php echo $colletion['name'];?></a></dt>
                  <dd><em>����:
                    <?php echo dnumber($colletion['threadnum']); ?>                    </em>, <em>����:
                    <?php echo dnumber($colletion['commentnum']); ?>                    </em></dd>
                  <dd>
                    <?php if($colletion['lastpost']) { ?>
                    <?php if($forumcolumns < 3) { ?>
                    <a href="forum.php?mod=redirect&amp;tid=<?php echo $colletion['lastpost'];?>&amp;goto=lastpost#lastpost" class="xi2">
                    <?php echo cutstr($colletion['lastsubject'], 30); ?>                    </a>
                    <?php } else { ?>
                    <a href="forum.php?mod=redirect&amp;tid=<?php echo $colletion['lastpost'];?>&amp;goto=lastpost#lastpost">��󷢱�:
                    <?php echo dgmdate($colletion[lastposttime]);?>                    </a>
                    <?php } ?>
                    <?php } else { ?>
                    ��δ
                    <?php } ?>
                  </dd>
                  <?php if(!empty($_G['setting']['pluginhooks']['index_followcollection_extra'][$colletion[ctid]])) echo $_G['setting']['pluginhooks']['index_followcollection_extra'][$colletion[ctid]];?>
                </dl></td>
              <?php $ctorderid++;?>              <?php } ?>
              <?php if(($columnspad = $ctorderid % $forumcolumns) > 0) { ?>
              <?php echo str_repeat('<td class="fl_g"'.($forumcolwidth ? " width=\"$forumcolwidth\"" : '').'></td>', $forumcolumns - $columnspad);; ?>              <?php } ?>
            </tr>
          </table>
        </div>
      </div>
      <?php } ?>

      <?php if(empty($gid) && !empty($forum_favlist)) { ?>
      <?php $forumscount = count($forum_favlist);?>      <?php $forumcolumns = $forumscount > 3 ? ($forumscount == 4 ? 4 : 5) : 1;?>      <?php $forumcolwidth = (floor(100 / $forumcolumns) - 0.1).'%';?>      <div class="bm bmw bus_box <?php if($forumcolumns) { ?> flg<?php } ?> cl">
        <div class="bm_h cl">
          <span class="o">
            <img id="category_0_img" src="<?php echo IMGDIR;?>/<?php echo $collapse['collapseimg_0'];?>" title="����/չ��" alt="����/չ��" onclick="toggle_collapse('category_0');" />
          </span>
          <h2><a href="home.php?mod=space&amp;do=favorite&amp;type=forum">���ղصİ��</a></h2>
        </div>
        <div id="category_0" class="bm_c" style="<?php echo $collapse['category_0']; ?>">
          <table cellspacing="0" cellpadding="0" class="fl_tb">
            <tr>
            <?php $favorderid = 0;?>            <?php if(is_array($forum_favlist)) foreach($forum_favlist as $key => $favorite) { ?>            <?php if($favforumlist[$favorite['id']]) { ?>
            <?php $forum=$favforumlist[$favorite[id]];?>            <?php $forumurl = !empty($forum['domain']) && !empty($_G['setting']['domain']['root']['forum']) ? 'http://'.$forum['domain'].'.'.$_G['setting']['domain']['root']['forum'] : 'forum.php?mod=forumdisplay&fid='.$forum['fid'];?>                <td class="fl_g" width="25%">
                  <div class="fl_icn_g" style="width:64px">
                  <?php if($forum['icon']) { ?>
                    <?php echo $forum['icon'];?>
                  <?php } else { ?>
                    <a href="<?php echo $forumurl;?>"<?php if($forum['redirect']) { ?> target="_blank"<?php } ?>><img src="<?php echo IMGDIR;?>/forum<?php if($forum['folder']) { ?>_new<?php } ?>.gif" alt="<?php echo $forum['name'];?>" /></a>
                  <?php } ?>
                  </div>
                  <dl<?php if(!empty($forum['extra']['iconwidth']) && !empty($forum['icon'])) { ?> style="margin-left: <?php echo $forum['extra']['iconwidth'];?>px;"<?php } ?>>
                    <dt><a href="<?php echo $forumurl;?>"<?php if($forum['redirect']) { ?> target="_blank"<?php } if($forum['extra']['namecolor']) { ?> style="color: <?php echo $forum['extra']['namecolor'];?>;"<?php } ?>><?php echo $forum['name'];?></a><?php if($forum['todayposts'] && !$forum['redirect']) { ?><em class="xw0 xi1" title="����"> (<?php echo $forum['todayposts'];?>)</em><?php } ?></dt>
                    <?php if(empty($forum['redirect'])) { ?><dd><em>����: <?php echo dnumber($forum['threads']); ?></em>, <em>����: <?php echo dnumber($forum['posts']); ?></em></dd><?php } ?>
                    <dd>
                    <?php if($forum['permission'] == 1) { ?>
                      ˽�ܰ��
                    <?php } else { ?>
                      <?php if($forum['redirect']) { ?>
                        <a href="<?php echo $forumurl;?>" class="xi2">���ӵ��ⲿ��ַ</a>
                      <?php } elseif(is_array($forum['lastpost'])) { ?>
                        <?php if($forumcolumns < 3) { ?>
                          <a href="forum.php?mod=redirect&amp;tid=<?php echo $forum['lastpost']['tid'];?>&amp;goto=lastpost#lastpost" class="xi2"><?php echo cutstr($forum['lastpost']['subject'], 30); ?></a>
                        <?php } else { ?>
                          <a href="forum.php?mod=redirect&amp;tid=<?php echo $forum['lastpost']['tid'];?>&amp;goto=lastpost#lastpost">��󷢱�: <?php echo $forum['lastpost']['dateline'];?></a>
                        <?php } ?>
                      <?php } else { ?>
                        ��δ
                      <?php } ?>
                    <?php } ?>
                    </dd>
                    <?php if(!empty($_G['setting']['pluginhooks']['index_favforum_extra'][$forum[fid]])) echo $_G['setting']['pluginhooks']['index_favforum_extra'][$forum[fid]];?>
                  </dl>
                </td>
                <?php $favorderid++;?>            <?php } ?>
            <?php } ?>
            <?php if(($columnspad = $favorderid % $forumcolumns) > 0) { echo str_repeat('<td class="fl_g"'.($forumcolwidth ? " width=\"$forumcolwidth\"" : '').'></td>', $forumcolumns - $columnspad);; } ?>

          </table>

        </div>
      </div>
      <?php echo adshow("intercat/bm a_c/-1");?>    <?php } ?>

      <?php if(is_array($catlist)) foreach($catlist as $key => $cat) { ?>      <?php if(!empty($_G['setting']['pluginhooks']['index_catlist'][$cat[fid]])) echo $_G['setting']['pluginhooks']['index_catlist'][$cat[fid]];?>
      <div class="bm bmw <?php if($cat['forumcolumns']) { ?> flg<?php } ?> cl bus_box busbb">
        <div class="bm_h cl"> <span class="o"> <img id="category_<?php echo $cat['fid'];?>_img" src="<?php echo IMGDIR;?>/<?php echo $cat['collapseimg'];?>" title="����/չ��" alt="����/չ��" onclick="toggle_collapse('category_<?php echo $cat['fid'];?>');" /> </span>
          <?php if($cat['moderators']) { ?>
          <span class="y">��������: <?php echo $cat['moderators'];?></span>
          <?php } ?>
          <?php $caturl = !empty($cat['domain']) && !empty($_G['setting']['domain']['root']['forum']) ? 'http://'.$cat['domain'].'.'.$_G['setting']['domain']['root']['forum'] : '';?>          <h2 class="tt"><a href="<?php if(!empty($caturl)) { ?><?php echo $caturl;?><?php } else { ?>forum.php?gid=<?php echo $cat['fid'];?><?php } ?>" style="<?php if($cat['extra']['namecolor']) { ?>color: <?php echo $cat['extra']['namecolor'];?>;<?php } ?>"><?php echo $cat['name'];?></a></h2>
        </div>
        <div id="category_<?php echo $cat['fid'];?>" class="bm_c" style="<?php echo $collapse['category_'.$cat['fid']]; ?>">
          <table cellspacing="0" cellpadding="0" class="fl_tb">
            <tr>
              <?php if(is_array($cat['forums'])) foreach($cat['forums'] as $forumid) { ?>              <?php $forum=$forumlist[$forumid];?>              <?php $forumurl = !empty($forum['domain']) && !empty($_G['setting']['domain']['root']['forum']) ? 'http://'.$forum['domain'].'.'.$_G['setting']['domain']['root']['forum'] : 'forum.php?mod=forumdisplay&fid='.$forum['fid'];?>              <td class="fl_g" width="25%"><div class="fl_icn_g" style="width:64px;">
                  <?php if($forum['icon']) { ?>
                  <?php echo $forum['icon'];?>
                  <?php } else { ?>
                  <a href="<?php echo $forumurl;?>"<?php if($forum['redirect']) { ?> target="_blank"<?php } ?>><img src="<?php echo $_G['style']['styleimgdir'];?>/forum<?php if($forum['folder']) { ?>_new<?php } ?>.gif" alt="<?php echo $forum['name'];?>" /></a>
                  <?php } ?>
                </div>
                <dl<?php if(!empty($forum['extra']['iconwidth']) && !empty($forum['icon'])) { ?> style="margin-left: <?php echo $forum['extra']['iconwidth'];?>px;"<?php } ?>>
                <dt><a href="<?php echo $forumurl;?>"<?php if($forum['redirect']) { ?> target="_blank"<?php } if($forum['extra']['namecolor']) { ?> style="color: <?php echo $forum['extra']['namecolor'];?>;"<?php } ?>><?php echo $forum['name'];?></a>
                  <?php if($forum['todayposts'] && !$forum['redirect']) { ?>
                  <em class="xw0 xi1" title="����"> (<?php echo $forum['todayposts'];?>)</em>
                  <?php } ?>
                </dt>
                <?php if(empty($forum['redirect'])) { ?>
                <dd><em>����:
                  <?php echo dnumber($forum['threads']); ?>                  </em>, <em>����:
                  <?php echo dnumber($forum['posts']); ?>                  </em></dd>
                <?php } ?>
                <dd>
                  <?php if($forum['permission'] == 1) { ?>
                  ˽�ܰ��
                  <?php } else { ?>
                  <?php if($forum['redirect']) { ?>
                  <a href="<?php echo $forumurl;?>" class="xi2">���ӵ��ⲿ��ַ</a>
                  <?php } elseif(is_array($forum['lastpost'])) { ?>
                  <a href="forum.php?mod=redirect&amp;tid=<?php echo $forum['lastpost']['tid'];?>&amp;goto=lastpost#lastpost">��󷢱�: <?php echo $forum['lastpost']['dateline'];?></a>
                  <?php } else { ?>
                  ��δ
                  <?php } ?>
                  <?php } ?>
                </dd>
                <?php if(!empty($_G['setting']['pluginhooks']['index_forum_extra'][$forum[fid]])) echo $_G['setting']['pluginhooks']['index_forum_extra'][$forum[fid]];?>
        <?php if(!empty($_G['setting']['pluginhooks']['index_forum_extra'][$forum[fid]])) echo $_G['setting']['pluginhooks']['index_forum_extra'][$forum[fid]];?>
                </dl>
              </td>
        

              <?php } ?>
              <?php echo $cat['endrows'];?> </tr>
          </table>
        </div>
      </div>
      <?php echo adshow("intercat/bm a_c/$cat[fid]");?>      <?php } ?>
      <?php if(!empty($collectiondata['data'])) { ?>
      <?php $forumscount = count($collectiondata['data']);?>      <?php $forumcolumns = 4;?>      <?php $forumcolwidth = (floor(100 / $forumcolumns) - 0.1).'%';?>      <div class="bm bmw <?php if($forumcolumns) { ?> flg<?php } ?> cl bus_box busbb">
        <div class="bm_h cl"> <span class="o"> <img id="category_-2_img" src="<?php echo IMGDIR;?>/<?php echo $collapse['collapseimg_-2'];?>" title="����/չ��" alt="����/չ��" onclick="toggle_collapse('category_-2');" /> </span>
          <h2 class="tt"><a href="forum.php?mod=collection">��ר���Ƽ�</a></h2>
        </div>
        <div id="category_-2" class="bm_c" style="<?php echo $collapse['category_-2']; ?>">
          <table cellspacing="0" cellpadding="0" class="fl_tb">
            <tr>
              <?php $ctorderid = 0;?>              <?php if(is_array($collectiondata['data'])) foreach($collectiondata['data'] as $key => $colletion) { ?>              <?php if($ctorderid && ($ctorderid % $forumcolumns == 0)) { ?>
            </tr>
            <?php if($ctorderid < $forumscount) { ?>
            <tr class="fl_row">
              <?php } ?>
              <?php } ?>
              <td class="fl_g"<?php if($forumcolwidth) { ?> width="<?php echo $forumcolwidth;?>"<?php } ?>><div class="fl_icn_g"> <a href="forum.php?mod=collection&amp;action=view&amp;ctid=<?php echo $colletion['ctid'];?>" target="_blank"><img src="<?php echo $_G['style']['styleimgdir'];?>/forum.gif" alt="<?php echo $colletion['name'];?>" /></a> </div>
                <dl>
                  <dt><a href="forum.php?mod=collection&amp;action=view&amp;ctid=<?php echo $colletion['ctid'];?>"><?php echo $colletion['name'];?></a></dt>
                  <dd><em>����:
                    <?php echo dnumber($colletion['threadnum']); ?>                    </em>, <em>����:
                    <?php echo dnumber($colletion['commentnum']); ?>                    </em></dd>
                  <dd>
                    <?php if($colletion['lastpost']) { ?>
                    <?php if($forumcolumns < 3) { ?>
                    <a href="forum.php?mod=redirect&amp;tid=<?php echo $colletion['lastpost'];?>&amp;goto=lastpost#lastpost" class="xi2">
                    <?php echo cutstr($colletion['lastsubject'], 30); ?>                    </a>
                    <?php } else { ?>
                    <a href="forum.php?mod=redirect&amp;tid=<?php echo $colletion['lastpost'];?>&amp;goto=lastpost#lastpost">��󷢱�:
                    <?php echo dgmdate($colletion[lastposttime]);?>                    </a>
                    <?php } ?>
                    <?php } else { ?>
                    ��δ
                    <?php } ?>
                  </dd>
                  <?php if(!empty($_G['setting']['pluginhooks']['index_datacollection_extra'][$colletion[ctid]])) echo $_G['setting']['pluginhooks']['index_datacollection_extra'][$colletion[ctid]];?>
                </dl></td>
              <?php $ctorderid++;?>              <?php } ?>
              <?php if(($columnspad = $ctorderid % $forumcolumns) > 0) { ?>
              <?php echo str_repeat('<td class="fl_g"'.($forumcolwidth ? " width=\"$forumcolwidth\"" : '').'></td>', $forumcolumns - $columnspad);; ?>              <?php } ?>
            </tr>
          </table>
        </div>
      </div>
      <?php } ?>
    </div>
    <?php if(!empty($_G['setting']['pluginhooks']['index_middle'])) echo $_G['setting']['pluginhooks']['index_middle'];?>
    <div class="wp mtn">
      <!--[diy=diy3]--><div id="diy3" class="area"></div><!--[/diy]-->
    </div>
    <?php if(empty($gid) && $_G['setting']['whosonlinestatus']) { ?>
    <div id="online" class="oll bus_oll busbb">
      <div class="bm_h">
        <?php if($detailstatus) { ?>
        <span class="o"><a href="forum.php?showoldetails=no#online" title="����/չ��"><img src="<?php echo IMGDIR;?>/collapsed_no.gif" alt="����/չ��" /></a></span>
        <h3> <strong><a href="home.php?mod=space&amp;do=friend&amp;view=online&amp;type=member">���߻�Ա</a></strong> <span class="xs1">- <strong><?php echo $onlinenum;?></strong> ������
          - <strong><?php echo $membercount;?></strong> ��Ա(<strong><?php echo $invisiblecount;?></strong> ����), <strong><?php echo $guestcount;?></strong> λ�ο�
          - ��߼�¼�� <strong><?php echo $onlineinfo['0'];?></strong> �� <strong><?php echo $onlineinfo['1'];?></strong>.</span> </h3>
        <?php } else { ?>
        <?php if(empty($_G['setting']['sessionclose'])) { ?>
        <span class="o"><a href="forum.php?showoldetails=yes#online" title="����/չ��"><img src="<?php echo IMGDIR;?>/collapsed_yes.gif" alt="����/չ��" /></a></span>
        <?php } ?>
        <h3> <strong>
          <?php if(!empty($_G['setting']['whosonlinestatus'])) { ?>
          ���߻�Ա
          <?php } else { ?>
          <a href="home.php?mod=space&amp;do=friend&amp;view=online&amp;type=member">���߻�Ա</a>
          <?php } ?>
          </strong> <span class="xs1">- �ܼ� <strong><?php echo $onlinenum;?></strong> ������
          <?php if($membercount) { ?>
          - <strong><?php echo $membercount;?></strong> ��Ա,<strong><?php echo $guestcount;?></strong> λ�ο�
          <?php } ?>
          - ��߼�¼�� <strong><?php echo $onlineinfo['0'];?></strong> �� <strong><?php echo $onlineinfo['1'];?></strong>.</span> </h3>
        <?php } ?>
      </div>
      <?php if($_G['setting']['whosonlinestatus'] && $detailstatus) { ?>
      <dl id="onlinelist" class="bm_c">
        <dt class="ptm pbm bbda"><?php echo $_G['cache']['onlinelist']['legend'];?></dt>
        <?php if($detailstatus) { ?>
        <dd class="ptm pbm">
          <ul class="cl">
            <?php if($whosonline) { ?>
            <?php if(is_array($whosonline)) foreach($whosonline as $key => $online) { ?>            <li title="ʱ��: <?php echo $online['lastactivity'];?>"> <img src="<?php echo STATICURL;?>image/common/<?php echo $online['icon'];?>" alt="icon" />
              <?php if($online['uid']) { ?>
              <a href="home.php?mod=space&amp;uid=<?php echo $online['uid'];?>"><?php echo $online['username'];?></a>
              <?php } else { ?>
              <?php echo $online['username'];?>
              <?php } ?>
            </li>
            <?php } ?>
            <?php } else { ?>
            <li style="width: auto">��ǰֻ���οͻ�������Ա����</li>
            <?php } ?>
          </ul>
        </dd>
        <?php } ?>
      </dl>
      <?php } ?>
  
    <?php if(empty($gid) && ($_G['cache']['forumlinks']['0'] || $_G['cache']['forumlinks']['1'] || $_G['cache']['forumlinks']['2'])) { ?>
    <div class="lk">
      <div id="category_lk" class="bm_c ptm">
        <?php if($_G['cache']['forumlinks']['0']) { ?>
        <ul class="m mbn cl">
          <?php echo $_G['cache']['forumlinks']['0'];?>
        </ul>
        <?php } ?>
        <?php if($_G['cache']['forumlinks']['1']) { ?>
        <div class="mbn cl"> <?php echo $_G['cache']['forumlinks']['1'];?> </div>
        <?php } ?>
        <?php if($_G['cache']['forumlinks']['2']) { ?>
        <ul class="x mbm cl">
          <?php echo $_G['cache']['forumlinks']['2'];?>
        </ul>
        <?php } ?>
      </div>
    </div>
    <?php } ?>
  
     </div>
    <?php } ?>
   <?php if(!empty($_G['setting']['pluginhooks']['index_bottom'])) echo $_G['setting']['pluginhooks']['index_bottom'];?>
  </div>
  
  <?php if($_G['setting']['forumallowside']) { ?>
    <div id="sd" class="sd" style="display:none">
      <?php if(!empty($_G['setting']['pluginhooks']['index_side_top'])) echo $_G['setting']['pluginhooks']['index_side_top'];?>
      <div class="drag">
        <!--[diy=diy2]--><div id="diy2" class="area"></div><!--[/diy]-->
      </div>
      <?php if(!empty($_G['setting']['pluginhooks']['index_side_bottom'])) echo $_G['setting']['pluginhooks']['index_side_bottom'];?>
    </div>
  <?php } ?>

</div>
</div>
<?php if($_G['group']['radminid'] == 1) { helper_manyou::checkupdate();?><?php } include template('common/footer'); ?>