<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); hookscriptoutput('viewthread');?>
<?php if($_G['fid'] == 41 || $_G['fid'] == 52) { include template('forum/viewthread_busphoto'); } else { $threadsort = $threadsorts = null;?><?php include template('common/header'); ?><script src="<?php echo $_G['setting']['jspath'];?>forum.js?<?php echo VERHASH;?>" type="text/javascript" charset="<?php echo CHARSET;?>"></script>
<script type="text/javascript">var fid = parseInt('<?php echo $_G['fid'];?>'), tid = parseInt('<?php echo $_G['tid'];?>');</script>
<script src="<?php echo $_G['setting']['jspath'];?>forum_viewthread.js?<?php echo VERHASH;?>" type="text/javascript" charset="<?php echo CHARSET;?>"></script>
<script type="text/javascript">zoomstatus = parseInt(<?php echo $_G['setting']['zoomstatus'];?>);var imagemaxwidth = '<?php echo $_G['setting']['imagemaxwidth'];?>';var aimgcount = new Array();</script>



<div class="bus_w100 mobanbus_view_bd bus_fl mb20" id="newsBox">
<?php if(!empty($_G['setting']['pluginhooks']['viewthread_top_mobile'])) echo $_G['setting']['pluginhooks']['viewthread_top_mobile'];?>
<!-- main postlist start -->
<div class="postlist bus_w100 bus_fl mb10"><?php $postcount = 0;?><?php if(is_array($postlist)) foreach($postlist as $post) { $needhiddenreply = ($hiddenreplies && $_G['uid'] != $post['authorid'] && $_G['uid'] != $_G['forum_thread']['authorid'] && !$post['first'] && !$_G['forum']['ismoderator']);?><?php if(!empty($_G['setting']['pluginhooks']['viewthread_posttop_mobile'][$postcount])) echo $_G['setting']['pluginhooks']['viewthread_posttop_mobile'][$postcount];?>
<?php if($post['first']) { ?>

<div class="bus_viewbanner">
<?php if($thread['attachment'] == 2) { $table='forum_attachment_'.substr($thread['tid'], -1);?><?php $thread['aid'] = DB::result_first("SELECT aid FROM ".DB::table($table)." WHERE tid='$thread[tid]' AND isimage!='0'");?><img src="<?php echo(getforumimg($thread['aid'],0,500,500))?>" />
<?php } else { } ?>
<i></i>

<div class="bus_vtt">
<div class="bus_w100 bus_fl htt">
<h2>
<?php echo $_G['forum_thread']['subject'];?>
<?php if($_G['forum_thread']['price'] > 0) { ?>
<span>����</span>
<?php } ?>
</h2>
</div>
<div class="bus_hf">
<div class="bus_fl">
<?php if($post['first'] && ($post['tags'] || $relatedkeywords) && $_GET['from'] != 'preview') { if($post['tags']) { $tagi = 0;?><?php if(is_array($post['tags'])) foreach($post['tags'] as $var) { ?><a title="<?php echo $var['1'];?>" href="misc.php?mod=tag&amp;id=<?php echo $var['0'];?>" target="_blank"><?php echo $var['1'];?></a><?php $tagi++;?><?php } } if($relatedkeywords) { ?><span><?php echo $relatedkeywords;?></span><?php } } ?>
</div>
<div class="bus_fr">
<em>�ظ���<?php echo $_G['forum_thread']['allreplies'];?><span class="ml10">�����<?php echo $_G['forum_thread']['views'];?></span></em>
</div>
</div>
</div>
</div>

<!-- Mobanbus_cn bus_viewtt end -->
   <div class="bus_viewbd plc cl pt20" id="pid<?php echo $post['pid'];?>">
       <div class="display bus_w100 bus_fl" href="#replybtn_<?php echo $post['pid'];?>">

<div class="bus_relative">
<div class="bus_manage bus_hide">
<?php if((($_G['forum']['ismoderator'] && $_G['group']['alloweditpost'] && (!in_array($post['adminid'], array(1, 2, 3)) || $_G['adminid'] <= $post['adminid'])) || ($_G['forum']['alloweditpost'] && $_G['uid'] && ($post['authorid'] == $_G['uid'] && $_G['forum_thread']['closed'] == 0) && !(!$alloweditpost_status && $edittimelimit && TIMESTAMP - $post['dbdateline'] > $edittimelimit)))) { ?>
<em><a href="#moption_<?php echo $post['pid'];?>" class="popup bus_colora pr10">����</a></em>

<div id="moption_<?php echo $post['pid'];?>" popup="true" class="manage" style="display:none;">
<?php if(!$_G['forum_thread']['special']) { ?>
<input type="button" value="�༭" class="redirect button" href="forum.php?mod=post&amp;action=edit&amp;fid=<?php echo $_G['fid'];?>&amp;tid=<?php echo $_G['tid'];?>&amp;pid=<?php echo $post['pid'];?><?php if($_G['forum_thread']['sortid']) { if($post['first']) { ?>&amp;sortid=<?php echo $_G['forum_thread']['sortid'];?><?php } } if(!empty($_GET['modthreadkey'])) { ?>&amp;modthreadkey=<?php echo $_GET['modthreadkey'];?><?php } ?>&amp;page=<?php echo $page;?>">
<?php } ?>
<input type="button" value="ɾ��" class="dialog button" href="forum.php?mod=topicadmin&amp;action=moderate&amp;fid=<?php echo $_G['fid'];?>&amp;moderate[]=<?php echo $_G['tid'];?>&amp;operation=delete&amp;optgroup=3&amp;from=<?php echo $_G['tid'];?>">
<input type="button" value="�ر�" class="dialog button" href="forum.php?mod=topicadmin&amp;action=moderate&amp;fid=<?php echo $_G['fid'];?>&amp;moderate[]=<?php echo $_G['tid'];?>&amp;from=<?php echo $_G['tid'];?>&amp;optgroup=4">
<input type="button" value="����" class="dialog button" href="forum.php?mod=topicadmin&amp;action=banpost&amp;fid=<?php echo $_G['fid'];?>&amp;tid=<?php echo $_G['tid'];?>&amp;topiclist[]=<?php echo $_G['forum_firstpid'];?>">
<input type="button" value="����" class="dialog button" href="forum.php?mod=topicadmin&amp;action=warn&amp;fid=<?php echo $_G['fid'];?>&amp;tid=<?php echo $_G['tid'];?>&amp;topiclist[]=<?php echo $_G['forum_firstpid'];?>">
</div>
<?php } ?>
</div>
</div>


       <div class="message" id="isfirst">
       		<div class="bus_w100">
                	<?php if($post['warned']) { ?>
                        <span class="quote">�ܵ�����</span>
                    <?php } ?>
                    <?php if(!$post['first'] && !empty($post['subject'])) { ?>
                        <h2><strong><?php echo $post['subject'];?></strong></h2>
                    <?php } ?>
                    <?php if($_G['adminid'] != 1 && $_G['setting']['bannedmessages'] & 1 && (($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5) || $post['status'] == -1 || $post['memberstatus'])) { ?>
                        <div class="quote">��ʾ: <em>���߱���ֹ��ɾ�� �����Զ�����</em></div>
                    <?php } elseif($_G['adminid'] != 1 && $post['status'] & 1) { ?>
                        <div class="quote">��ʾ: <em>����������Ա���������</em></div>
                    <?php } elseif($needhiddenreply) { ?>
                        <div class="quote">���������߿ɼ�</div>
                    <?php } elseif($post['first'] && $_G['forum_threadpay']) { include template('forum/viewthread_pay'); } else { ?>

                    	<?php if($_G['setting']['bannedmessages'] & 1 && (($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5))) { ?>
                            <div class="quote">��ʾ: <em>���߱���ֹ��ɾ�� �����Զ����Σ�ֻ�й���Ա���й���Ȩ�޵ĳ�Ա�ɼ�</em></div>
                        <?php } elseif($post['status'] & 1) { ?>
                            <div class="quote">��ʾ: <em>����������Ա��������Σ�ֻ�й���Ա���й���Ȩ�޵ĳ�Ա�ɼ�</em></div>
                        <?php } ?>

                        <?php if($post['first'] && $threadsort && $threadsortshow) { ?>
                        	<?php if($threadsortshow['optionlist'] && !($post['status'] & 1) && !$_G['forum_threadpay']) { ?>
                                <?php if($threadsortshow['optionlist'] == 'expire') { ?>
                                    ����Ϣ�Ѿ�����
                                <?php } else { ?>
                                    <div class="box_ex2 viewsort">
                                        <h4><?php echo $_G['forum']['threadsorts']['types'][$_G['forum_thread']['sortid']];?></h4>
                                    <?php if(is_array($threadsortshow['optionlist'])) foreach($threadsortshow['optionlist'] as $option) { ?>                                        <?php if($option['type'] != 'info') { ?>
                                            <?php echo $option['title'];?>: <?php if($option['value']) { ?><?php echo $option['value'];?> <?php echo $option['unit'];?><?php } else { ?><span class="grey">--</span><?php } ?><br />
                                        <?php } ?>
                                    <?php } ?>
                                    </div>
                                <?php } ?>
                            <?php } ?>
                        <?php } ?>
                        <?php if($post['first']) { if($threadsortshow['typetemplate']) { ?>
<?php echo $threadsortshow['typetemplate'];?>
<div class="clear"></div>

<?php echo $post['message'];?>

<?php } elseif($threadsortshow['optionlist']) { ?>
<div class="typeoption">
<?php if($threadsortshow['optionlist'] == 'expire') { ?>
����Ϣ�Ѿ�����
<?php } else { ?>
<h3><?php echo $_G['forum']['threadsorts']['types'][$_G['forum_thread']['sortid']];?></h3><?php if(is_array($threadsortshow['optionlist'])) foreach($threadsortshow['optionlist'] as $option) { if($option['type'] != 'info') { ?>
<li class="n_sort">
<span><?php echo $option['title'];?>:</span>
<span><?php if($option['value'] !== '') { ?><?php echo $option['value'];?> <?php echo $option['unit'];?><?php } else { ?>-<?php } ?></span>
</li>
<?php } } } ?>
</div>
<div class="clear"></div>

<?php echo $post['message'];?>

                           <?php } elseif(!$_G['forum_thread']['special']) { ?>

<?php echo $post['message'];?>

                            <?php } elseif($_G['forum_thread']['special'] == 1) { ?>
                               <?php include template('forum/viewthread_poll'); ?>                            <?php } elseif($_G['forum_thread']['special'] == 2) { ?>
                                <?php include template('forum/viewthread_trade'); ?>                            <?php } elseif($_G['forum_thread']['special'] == 3) { ?>
                                <?php include template('forum/viewthread_reward'); ?>                            <?php } elseif($_G['forum_thread']['special'] == 4) { ?>
                                <?php include template('forum/viewthread_activity'); ?>                            <?php } elseif($_G['forum_thread']['special'] == 5) { ?>
                                <?php include template('forum/viewthread_debate'); ?>                            <?php } elseif($threadplughtml) { ?>
                                
<?php echo $threadplughtml;?>
                                <?php echo $post['message'];?>

                            <?php } else { ?>

<?php echo $post['message'];?>

                            <?php } ?>
                        <?php } else { ?>

<?php echo $post['message'];?>

                        <?php } } if($_G['setting']['mobile']['mobilesimpletype'] == 0) { if($post['attachment']) { ?>
   <div class="quote">
   ����: <em><?php if($_G['uid']) { ?>�����ڵ��û����޷����ػ�鿴����<?php } else { ?>����Ҫ<a href="member.php?mod=logging&amp;action=login">��¼</a>�ſ������ػ�鿴������û���ʺţ�<a href="member.php?mod=<?php echo $_G['setting']['regname'];?>" title="ע���ʺ�"><?php echo $_G['setting']['reglinkname'];?></a><?php } ?></em>
   </div>
<?php } elseif($post['imagelist'] || $post['attachlist']) { ?>
   <?php if($post['imagelist']) { if(count($post['imagelist']) == 1) { ?>
<ul class="img_one"><?php echo showattach($post, 1); ?></ul>
<?php } else { ?>
<ul class="img_list cl vm"><?php echo showattach($post, 1); ?></ul>
<?php } } if($post['attachlist']) { ?>
<ul><?php echo showattach($post); ?></ul>
<?php } } } ?>					
</div>
</div>
<!-- Mobanbus_cn message end -->

<?php if($post['relateitem']) { ?>
<div class="bus_relative_tj buxbox">
<ul class="buxbox"><?php if(is_array($post['relateitem'])) foreach($post['relateitem'] as $var) { ?><li><a href="forum.php?mod=viewthread&amp;tid=<?php echo $var['tid'];?>"><?php echo $var['subject'];?></a></li>
<?php } ?>
</ul>
</div>
<?php } ?>


<div class="bus_viewallreply"></div>
<style type="text/css">
.bus_viewallreply{width: 100%;float: left;background:#eee;height: 1px;}
</style>

      </div>
  </div>

<?php } else { ?>
  <div class="bus_replybd plc cl" id="pid<?php echo $post['pid'];?>">
       <div class="display" href="#replybtn_<?php echo $post['pid'];?>">
   <div class="bus_auther buxbox">
   <div class="authi">
   <img class="authilogo" src="<?php if(!$post['authorid'] || $post['anonymous']) { ?><?php echo avatar(0, small, true);?><?php } else { ?><?php echo avatar($post[authorid], small, true);?><?php } ?>" />
<em class="grey bus_fl">
<?php if($post['authorid'] && $post['username'] && !$post['anonymous']) { ?>
<b><a href="home.php?mod=space&amp;uid=<?php echo $post['authorid'];?>&amp;do=profile&amp;mobile=2" class="bus_colora"><?php echo $post['author'];?></a><span class="ml10"><?php echo $post['authortitle'];?></span></b>
<?php } else { if(!$post['authorid']) { ?>
<a href="javascript:;">�ο� <em><?php echo $post['useip'];?><?php if($post['port']) { ?>:<?php echo $post['port'];?><?php } ?></em></a>
<?php } elseif($post['authorid'] && $post['username'] && $post['anonymous']) { if($_G['forum']['ismoderator']) { ?><a href="home.php?mod=space&amp;uid=<?php echo $post['authorid'];?>&amp;do=profile&amp;mobile=2">����</a><?php } else { ?>����<?php } } else { ?>
<?php echo $post['author'];?> <em>���û��ѱ�ɾ��</em>
<?php } } ?>
</em>
<em class="bus_fr">
<?php if($post['authorid'] == $_G['uid']) { } else { if(!$_G['forum_thread']['special'] && !$rushreply && !$hiddenreplies && $_G['setting']['repliesrank'] && !$post['first'] && !($post['isWater'] && $_G['setting']['filterednovote'])) { ?>
<a class="replyadd bus_colora pr10" href="forum.php?mod=misc&amp;action=postreview&amp;do=support&amp;tid=<?php echo $_G['tid'];?>&amp;pid=<?php echo $post['pid'];?>&amp;hash=<?php echo FORMHASH;?>" <?php if($_G['uid']) { ?>onclick="ajaxmenu(this, 3000, 1, 0, '43', '');return false;"<?php } else { ?> onclick="showWindow('login', this.href)"<?php } ?> onmouseover="this.title = ($('review_support_<?php echo $post['pid'];?>').innerHTML ? $('review_support_<?php echo $post['pid'];?>').innerHTML : 0) + ' �� ֧��'" title="֧��"><i class="icon-thumbs-up pr10"></i><span id="review_support_<?php echo $post['pid'];?>"><?php echo $post['postreview']['support'];?></span></a>
<?php } } ?>
</em>
   </div>
   </div>

<div class="message" id="isfirst">
<span class="w96">
<?php echo $post['message'];?>
</span>
</div>
<!-- Mobanbus_cn message end -->

<div class="busbox">
<em class="bus_fl pl10">
<?php echo $post['dateline'];?>
</em>
<em class="bus_fl pl10">
<a id="replybtn_<?php echo $post['pid'];?>" href="forum.php?mod=post&amp;action=reply&amp;fid=<?php echo $_G['fid'];?>&amp;tid=<?php echo $_G['tid'];?>&amp;repquote=<?php echo $post['pid'];?>&amp;extra=<?php echo $_GET['extra'];?>&amp;page=<?php echo $page;?>">�ظ�</a>
</em>
<?php if($_G['forum']['ismoderator']) { ?>
<div class="bus_hide">
<em class="bus_fl pl10"><a href="#moption_<?php echo $post['pid'];?>" class="popup bus_colora">����</a></em>
<div id="moption_<?php echo $post['pid'];?>" popup="true" class="manage" style="display:none;">
<input type="button" value="�༭" class="redirect button" href="forum.php?mod=post&amp;action=edit&amp;fid=<?php echo $_G['fid'];?>&amp;tid=<?php echo $_G['tid'];?>&amp;pid=<?php echo $post['pid'];?><?php if(!empty($_GET['modthreadkey'])) { ?>&amp;modthreadkey=<?php echo $_GET['modthreadkey'];?><?php } ?>&amp;page=<?php echo $page;?>">
<?php if($_G['group']['allowdelpost']) { ?><input type="button" value="ɾ��" class="dialog button" href="forum.php?mod=topicadmin&amp;action=delpost&amp;fid=<?php echo $_G['fid'];?>&amp;tid=<?php echo $_G['tid'];?>&amp;operation=&amp;optgroup=&amp;page=&amp;topiclist[]=<?php echo $post['pid'];?>"><?php } if($_G['group']['allowbanpost']) { ?><input type="button" value="����" class="dialog button" href="forum.php?mod=topicadmin&amp;action=banpost&amp;fid=<?php echo $_G['fid'];?>&amp;tid=<?php echo $_G['tid'];?>&amp;operation=&amp;optgroup=&amp;page=&amp;topiclist[]=<?php echo $post['pid'];?>"><?php } if($_G['group']['allowwarnpost']) { ?><input type="button" value="����" class="dialog button" href="forum.php?mod=topicadmin&amp;action=warn&amp;fid=<?php echo $_G['fid'];?>&amp;tid=<?php echo $_G['tid'];?>&amp;operation=&amp;optgroup=&amp;page=&amp;topiclist[]=<?php echo $post['pid'];?>"><?php } ?>
</div>
</div>
<?php } if($_G['forum_thread']['special'] == 3 && ($_G['forum']['ismoderator'] && (!$_G['setting']['rewardexpiration'] || $_G['setting']['rewardexpiration'] > 0 && ($_G['timestamp'] - $_G['forum_thread']['dateline']) / 86400 > $_G['setting']['rewardexpiration']) || $_G['forum_thread']['authorid'] == $_G['uid']) && $post['authorid'] != $_G['forum_thread']['authorid'] && $post['first'] == 0 && $_G['uid'] != $post['authorid'] && $_G['forum_thread']['price'] > 0) { ?>
<em class="bus_hide bus_fl pl10"><a href="javascript:;" onclick="setanswer(<?php echo $post['pid'];?>, '<?php echo $_GET['from'];?>')" class="popup bus_colora">��Ѵ�</a></em>
<?php } ?>


</div>

       </div>
  </div>


<?php } ?>

   <?php if(!empty($_G['setting']['pluginhooks']['viewthread_postbottom_mobile'][$postcount])) echo $_G['setting']['pluginhooks']['viewthread_postbottom_mobile'][$postcount];?>
   <?php $postcount++;?>   <?php } ?>
   <!-- Mobanbus_cn bus_viewbd end -->
<div id="post_new"></div><div id="postlistreply" class="pl mobanbus_reply"><div id="post_new" style="display: none"></div></div>
<?php echo $multipage;?>
</div>
<!-- Mobanbus_cn postlist end -->


<?php if(!empty($_G['setting']['pluginhooks']['viewthread_bottom_mobile'])) echo $_G['setting']['pluginhooks']['viewthread_bottom_mobile'];?>
<script>
piclist = '';
if(jQuery("#isfirst img[id^='aimg_']").length) {
piclist = '<?php echo $_G['siteurl'];?>' + jQuery("#isfirst img[id^='aimg_']").first().attr('src');
};
</script>

</div>
<!-- Mobanbus_cn mobanbus_view_bd end -->


<script src="<?php echo $_G['siteurl'];?>template/mobanbus_motev1/mobile_st/js/mobanbus_lazy.js" type="text/javascript"></script>
<div class="bus_replyfixbox"></div><?php $nofooter = true;?><?php include template('common/footer'); } ?>