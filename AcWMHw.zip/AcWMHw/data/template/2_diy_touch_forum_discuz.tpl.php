<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); hookscriptoutput('discuz');?>
<?php if($_G['setting']['mobile']['mobilehotthread'] && $_GET['forumlist'] != 1) { dheader('Location:portal.php?mod=index');exit;?><?php } include template('common/header'); ?><style type="text/css">
.mobanbus_header .busleft, .mobanbus_header .busmoreshare, .footer{display: none;}
</style>


<div class="bus_forumtop busbox">
<div class="forumtop_item"><i><?php echo $todayposts;?></i><span>����</span></div>
<div class="forumtop_item"><i><?php echo $posts;?></i><span>����</span></div>
<div class="forumtop_item"><i><?php echo $_G['cache']['userstats']['totalmembers'];?></i><span>��Ա</span></div>
</div>

<div class="busbox">

<script type="text/javascript">
function getvisitclienthref() {
var visitclienthref = '';
if(ios) {
visitclienthref = 'https://itunes.apple.com/cn/app/zhang-appv1-lun-tan/id489399408?mt=8';
} else if(andriod) {
visitclienthref = 'http://www.discuz.net/mobile.php?platform=android';
}
return visitclienthref;
}
</script>

<?php if($_GET['visitclient']) { ?>

<header class="header">
    <div class="nav">
<span>��ܰ��ʾ</span>
    </div>
</header>
<div class="cl">
<div class="clew_con">
<h2 class="tit">������̳�ֻ��ͻ���</h2>
<p>��ʱ�������̳<input class="redirect button" id="visitclientid" type="button" value="�������" href="" /></p>
<h2 class="tit">iPhone,Andriod�������ֻ�</h2>
<p>ֱ�ӵ�¼�ֻ��棬�Ķ��������<input class="redirect button" type="button" value="�����ֻ���" href="<?php echo $_GET['visitclient'];?>" /></p>
</div>
</div>
<script type="text/javascript">
var visitclienthref = getvisitclienthref();
if(visitclienthref) {
$('#visitclientid').attr('href', visitclienthref);
} else {
window.location.href = '<?php echo $_GET['visitclient'];?>';
}
</script>

<?php } else { ?>


<?php if(!empty($_G['setting']['pluginhooks']['index_top_mobile'])) echo $_G['setting']['pluginhooks']['index_top_mobile'];?>
<!-- main forumlist start -->
<div class="wps busbox" id="wp">

<?php if(empty($gid) && !empty($forum_favlist)) { $forumscount = count($forum_favlist);?><?php $forumcolumns = $forumscount > 3 ? ($forumscount == 4 ? 4 : 5) : 1;?><?php $forumcolwidth = (floor(100 / $forumcolumns) - 0.1).'%';?><div class="bus_forumbd">
<div class="bus_forum_tt cl">
<h2><a href="javascript:;">���ղصİ��</a></h2>
</div>
<div id="sub_forum_<?php echo $cat['fid'];?>" class="bus_forum">
<ul><?php if(is_array($forum_favlist)) foreach($forum_favlist as $key => $favorite) { ?>  <?php $forum=$favforumlist[$favorite[id]];?>  <?php $forumurl = !empty($forum['domain']) && !empty($_G['setting']['domain']['root']['forum']) ? 'http://'.$forum['domain'].'.'.$_G['setting']['domain']['root']['forum'] : 'forum.php?mod=forumdisplay&fid='.$forum['fid'];?><li>
<div class="bus_forum_pic">
<?php if($forum['icon']) { ?>
<?php echo $forum['icon'];?>
<?php } else { ?>
<a href="forum.php?mod=forumdisplay&amp;fid=<?php echo $forum['fid'];?>"<?php if($forum['redirect']) { ?> <?php } ?>><img src="<?php echo $_G['style']['styleimgdir'];?>/forum<?php if($forum['folder']) { ?>_new<?php } ?>.gif" alt="<?php echo $forum['name'];?>" /></a>
<?php } ?>
<div class="bus_forum_txt">
<a href="forum.php?mod=forumdisplay&amp;fid=<?php echo $forum['fid'];?>">
<div><?php echo $forum['name'];?></div>
</a>	
</div>
</div>
</li>
<?php } ?>
</ul>
</div>
</div>
<?php } if(is_array($catlist)) foreach($catlist as $key => $cat) { ?><div class="bus_forumbd">
<div class="bus_forum_tt cl">
<h2><a href="forum.php?gid=<?php echo $cat['fid'];?>&amp;mobile=2"><?php echo $cat['name'];?></a></h2>
</div>
<div id="sub_forum_<?php echo $cat['fid'];?>" class="bus_forum">
<ul><?php if(is_array($cat['forums'])) foreach($cat['forums'] as $forumid) { $forum=$forumlist[$forumid];?><li>
<div class="bus_forum_pic">
<?php if($forum['icon']) { ?>
                <?php echo $forum['icon'];?>
                <?php } else { ?>
                <a href="forum.php?mod=forumdisplay&amp;fid=<?php echo $forum['fid'];?>"<?php if($forum['redirect']) { ?> <?php } ?>><img src="<?php echo $_G['style']['styleimgdir'];?>/forum<?php if($forum['folder']) { ?>_new<?php } ?>.gif" alt="<?php echo $forum['name'];?>" /></a>
                <?php } ?>
<div class="bus_forum_txt">
<a href="forum.php?mod=forumdisplay&amp;fid=<?php echo $forum['fid'];?>">
<div><?php echo $forum['name'];?></div>
</a>	
</div>
</div>
</li>
<?php } ?>
</ul>
</div>
</div>
<?php } ?>
</div>
<!-- main forumlist end -->
<?php if(!empty($_G['setting']['pluginhooks']['index_middle_mobile'])) echo $_G['setting']['pluginhooks']['index_middle_mobile'];?>

<?php } ?>
</div>
<!-- Mobanbus_cn mobanbus_bd end -->

<script type="text/javascript">
(function() {
<?php if(!$_G['setting']['mobile']['mobileforumview']) { ?>
jQuery('.bus_forum').css('display', 'block');
<?php } else { ?>
jQuery('.bus_forum').css('display', 'none');
<?php } ?>
jQuery('.subforumshow').on('click', function() {
var obj = jQuery(this);
var subobj = jQuery(obj.attr('href'));
if(subobj.css('display') == 'none') {
subobj.css('display', 'block');
} else {
subobj.css('display', 'none');
}
});
 })();
</script><?php $nofooter = true;?><?php include template('common/footer'); ?>