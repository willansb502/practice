<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); hookscriptoutput('index');?><?php include template('common/header'); ?><style>
.keke_chongzhi{ font-family:Microsoft Yahei;margin:15px auto}
.side{float:left;width:200px; background:#FFF;}
.czmain{ margin-left:220px;background:#FFF; position:relative}
.kkclearfix:after {clear: both;}
.kkclearfix:before, .kkclearfix:after {content: " ";display: table;}
.kksidebar{min-height:700px;border:1px solid #eee;background-color:#fff;font-size:14px}
.kksidebar li{height:48px;border-bottom:1px solid #eee;line-height:48px}
.kksidebar li a{display:block;margin-left:15px;text-decoration:none; }
.kksidebar li.active>a{text-decoration:none;color:#FFF}
.kksidebar li.active{background-color:<?php echo $keke_chongzhi['lnavcolor'];?>;color:#fff}
.keke_chongzhi_mylist{border:1px solid #eee; padding:30px 40px; box-sizing:border-box}
.keke_chongzhi_mylist ul{ padding:10px 20px}
.keke_chongzhi_mylist ul li{ width:100%;  line-height:20px; font-size:14px; margin:0px auto; padding:10px 0px;  border-bottom:1px solid #EEE}
.keke_chongzhi_mylist ul li .pup{ font-size:16px;}
.keke_chongzhi_mylist ul li .dow{ font-size:12px; color:#999}
.keke_chongzhi_mylist ul li span{ float:right}
.keke_chongzhi_mylist ul li .mzb{ color:#999; font-size:13px; display:inline-block; line-height:18px; margin:0 5px}
.noorder{ font-size:16px; text-align:center; color:#999}
.chargebox{border:1px solid #eee; padding-top:30px}
.chargebox .rowss{padding:15px 0; float:left; width:100%;}
.chargebox .labels{float:left;width:180px;color:#959595;text-align:right}
.chargebox .package-list{margin-left:-7px}
.chargebox .package-list li{float:left;margin:7px;padding:8px;width:120px;border:1px solid #d7d7d7;border-radius:3px;text-align:center;cursor:pointer;position:relative; white-space: nowrap; z-index:1;}
.chargebox .package-list li cite{ border:0px dashed #eee;position:absolute; margin:0px; width:auto; left:-1px;text-align:center; top:-10px; z-index:9999; color:#fff; height:15px;line-height:15px; font-size:12px; padding:0px 10px 0px; text-align:center;  font-style:normal;background: -webkit-linear-gradient(to right, #ff4b1f, #ff9068);background: linear-gradient(to right, #ff4b1f, #ff9068); border-radius:10px 1px 10px 1px}
.chargebox .package-list li cite b{ font-weight:500; padding-left:18px;background: url(source/plugin/keke_chongzhi/template/images/ico003.png) left 1px no-repeat;}
.chargebox .package-list li>a{text-decoration:none}
.chargebox .package-list li>a:hover{color:#313131}
.chargebox .package-list li span{ font-weight:bold}
.chargebox .package-list li h4{color:#959595}
.chargebox .package-list li.on{border-color:#fc4e53;background:url(source/plugin/keke_chongzhi/template/images/jb.png) right bottom no-repeat}
.chargebox .package-list li.on .amount,.chargebox .package-list li.on .price{color:#fc4e53}
.chargebox .charge-custom{height:32px;line-height:32px}
.chargebox .charge-custom .czcontent{width:400px;white-space:nowrap}
.chargebox .charge-custom input[name=moneyQuantity]{width:100px;height:32px;outline:0;border:1px solid #d7d7d7;text-align:center}
.chargebox  #cardid{width:370px;height:32px;outline:0;border:1px solid #d7d7d7;text-align:center; border-radius: 1px; background:#fcfcfc}
.chargebox .charge-custom input::placeholder,.chargebox  #cardid::placeholder{ color:#999}
.chargebox .czcontent{float:left;padding-left:20px;width:450px;text-align:left}
.chargebox .user-info .balance-label{float:right}
.chargebox .charge-source-list{margin-left:-10px}
.chargebox .charge-source-list>li{position:relative;float:left;margin:5px 0 5px 10px;padding:8px 5px;width:130px;height:36px;border:1px solid #d7d7d7;border-radius:3px;text-align:center;cursor:pointer}
.chargebox .charge-source-list>li.active{border-color:#fc4e53}
.chargebox .charge-source-list>li.active:before{position:absolute;top:0;left:0;z-index:1;display:block;width:100%;height:100%;background:url(source/plugin/keke_chongzhi/template/images/jb.png) 100% 100% no-repeat;content:''}
.chargebox .charge-source-list>li img{max-width:100%}
.labelt{ color:#999}
.chargebox .charge-submit .czcontent{margin-left:180px;width:650px}
.btns{display:inline;padding:13px 90px;border-radius:3px;color:#fff;text-align:center;text-decoration:none;font-size:16px;line-height:45px;background-color: <?php echo $keke_chongzhi['btncolor'];?>;}
.btns:hover{background-color:#ff7579;color:#fff;text-decoration:none}
#ewm{ margin:0px;}
#ewm img,#ewm canvas{ border:1px solid #EAEAEA; padding:3px; max-height:250px; max-width:250px;}
#ewm canvas{ padding:26px}
.remind{ line-height:20px; text-align:left; color:#999}
.czred{ color:#fc4e53; font-size:14px}
.credittype{ position:relative;float:left; padding-left:20px; }
.credittype input[type="radio"] {opacity: 0;width: 20px;height: 20px;z-index: 9; position:absolute; left:0px; margin:0px;}	
.credittype input[type="radio"]:checked + label i {background-position: -16px 0;}
.credittype label{float:left; margin-right:15px;}
.credittype i{display: block;width: 16px;height: 16px; margin-right:5px;background: url(source/plugin/keke_chongzhi/template/images/icon-iptr.png) 0 0 no-repeat;background-size: 32px auto;position:absolute; left:0px;}
.czsmbox{ width:100%; margin:10px auto;  float:left; }
.czsmbox .czsm{ width:80%; margin:0 auto;border-top:1px #eee solid; padding:15px 0px; line-height:25px;}
.hdtips{ margin:0 0 0 10px; display:none}
.hdtips .reddd{ color:#fc4e53; margin:0 2px; font-weight:500;}
.sxs{ margin:0px 10px; color:#CCC; font-weight:500;}
.cardcztip{ margin-top:15px; line-height:25px; color:#aeb1ae; }
.cardcztip a{color:#fc4e53}
.cardypaybox .rowss{ height:100px !important; padding-top:20px;}
.cardypaybox{ display:inline-block;margin-top:15px;}
</style>
<div class="wp kkclearfix keke_chongzhi">
        <div class="side">
            <ul class="kksidebar">
                <?php if(file_exists('source/plugin/keke_wallet/keke_wallet.inc.php') && $_G['cache']['plugin']['keke_wallet']) { ?>
                <li <?php if($_GET['id']==keke_wallet) { ?>class="active"<?php } ?> style="border-bottom:5px solid #F5F5F5">
                <a href="plugin.php?id=keke_wallet">!lt002!</a>
                </li>
                <?php } ?>
                <li <?php if(!$_GET['p']) { ?>class="active"<?php } ?>>
                    <a href="plugin.php?id=keke_chongzhi"><?php if($pcleftbtntxt['0']) { ?><?php echo $pcleftbtntxt['0'];?><?php } else { ?>���ֳ�ֵ<?php } ?></a>
                </li>
                <li <?php if($_GET['p']) { ?>class="active"<?php } ?> style="border-bottom:5px solid #F5F5F5">
                    <a href="plugin.php?id=keke_chongzhi&amp;p=my"><?php if($pcleftbtntxt['1']) { ?><?php echo $pcleftbtntxt['1'];?><?php } else { ?>��ֵ��¼<?php } ?></a>
                </li>
                 <?php if(file_exists('source/plugin/keke_tixian/keke_tixian.inc.php') && $_G['cache']['plugin']['keke_tixian']) { ?>
                <li <?php if((!$_GET['p']) && $_GET['id']==keke_tixian) { ?>class="active"<?php } ?>>
                    <a href="plugin.php?id=keke_tixian">!langt36!</a>
                </li>
                <li <?php if($_GET['p'] && $_GET['id']==keke_tixian) { ?>class="active"<?php } ?> style="border-bottom:5px solid #F5F5F5">
                    <a href="plugin.php?id=keke_tixian&amp;p=my">!langt39!</a>
                </li>
                <?php } ?>
                <?php if(file_exists('source/plugin/keke_group/keke_group.inc.php') && $_G['cache']['plugin']['keke_group']) { ?>
                <li>
                    <a href="plugin.php?id=keke_group"><?php if($grouppcleftbtntxt['0']) { ?><?php echo $grouppcleftbtntxt['0'];?><?php } else { ?>�û��鹺��<?php } ?></a>
                </li>
                <li <?php if($_GET['p']=='my' && $_GET['id']=='keke_group') { ?>class="active"<?php } ?>>
                    <a href="plugin.php?id=keke_group&amp;p=my"><?php if($grouppcleftbtntxt['1']) { ?><?php echo $grouppcleftbtntxt['1'];?><?php } else { ?>�û��鹺���¼<?php } ?></a>
                </li>
                <li <?php if($_GET['p']=='sw' && $_GET['id']=='keke_group') { ?>class="active"<?php } ?> style="border-bottom:5px solid #F5F5F5">
                    <a href="plugin.php?id=keke_group&amp;p=sw"><?php if($grouppcleftbtntxt['2']) { ?><?php echo $grouppcleftbtntxt['2'];?><?php } else { ?>�û����л�<?php } ?></a>
                </li>
                <?php } ?>
                <?php if(file_exists('source/plugin/keke_buyinvitecode/keke_buyinvitecode.inc.php') && $_G['cache']['plugin']['keke_buyinvitecode']) { ?>
                    <li <?php if((!$_GET['p']) && $_GET['id']==keke_buyinvitecode) { ?>class="active"<?php } ?>>
                        <a href="plugin.php?id=keke_buyinvitecode">�����빺��</a>
                    </li>
                <?php } ?>
            </ul>
        </div>
  		<div class="czmain kkclearfix">
        	<?php if($_GET['p']==my) { ?>
            <ul class="keke_chongzhi_mylist fix">
                <ul>
                    <?php if($list) { ?><?php echo $list;?><?php } else { ?><div class="noorder">���޳�ֵ��¼</div><?php } ?>
                </ul>
                <?php echo $multipage;?>
            </ul>
<?php } else { ?>
            <form name="alipayment" action="plugin.php" method="get"  id="alipayment" onkeydown="if(event.keyCode==13){return false;}">
            <input type="hidden" name="id" value="keke_chongzhi:payapi" >
            <input type="hidden" name="formhash" value="<?php echo FORMHASH;?>" >
            <ul class="chargebox kkclearfix">
                <li class="step1 active kkclearfix">
<div class="rowss user-info kkclearfix">
                        <div class="labels">
                            ��ǰ�˻���
                        </div>
                        <div class="czcontent kkclearfix">
                            <span class="nowcredit"><b class="czred"><?php echo $firstnowcredit;?></b> <?php echo $firstcreditname;?></span>
                        	<span class="balance-label">�ۼƳ�ֵ��<b class="czred"><?php echo $allmoney;?></b> <?php if($keke_chongzhi['total']) { ?>Ԫ<?php } else { ?>��<?php } ?></span>
                        </div>
</div>
                    <div class="moneypaybox">
                    <div class="rowss user-info kkclearfix" <?php if(!$n || $n==1 || (!$keke_chongzhi['payjsmchid'] && !$keke_chongzhi['payjskey'] && $keke_chongzhi['cardid'] && !$keke_chongzhi['appid'] && !$keke_chongzhi['privatekey'] && !$keke_chongzhi['privatekey'])) { ?>style="display:none"<?php } ?>>
                        <div class="labels">
                        	��ֵ�������ͣ�
                        </div>
                        <div class="czcontent kkclearfix">
                        	<?php echo $credittype;?>
                        </div>
</div>
                    <div class="rowss charge-select kkclearfix" <?php if(!$keke_chongzhi['payjsmchid'] && !$keke_chongzhi['payjskey'] && !$keke_chongzhi['appid'] && !$keke_chongzhi['privatekey'] && $keke_chongzhi['cardid']) { ?>style="display:none"<?php } ?>>
                        <div class="labels">
                            ��ֵ������
                        </div>
                        <div class="czcontent">
                            <ul id="package-list" class="package-list kkclearfix">
                            	<?php echo $preval;?>
                                <?php if($keke_chongzhi['custom']) { ?><li class="zdy"><span>�Զ���</span><h4>��ֵ���</h4></li><?php } ?>
                            </ul>
                        </div>
                    </div>
                    <div class="rowss charge-custom kkclearfix" style="display: none;">
                        <div class="labels">
                            �������ֵ��
                        </div>
                        <div class="czcontent">
                            <input type="text" name="moneyQuantity" id="moneyQuantity" value="<?php echo $preset['0'];?>" maxlength="10" autocomplete="off">
                            <span class="labelt zdybl"> Ԫ <span class="hdtips"></span> <b class="sxs">/</b><span class="bilitip">ÿ1Ԫ����<?php echo $bl;?><?php echo $firstcreditname;?></span></span>
                        </div>
                    </div>
                    <div class="rowss charge-cost kkclearfix" <?php if(!$keke_chongzhi['payjsmchid'] && !$keke_chongzhi['payjskey'] && !$keke_chongzhi['appid'] && !$keke_chongzhi['privatekey']) { ?>style="display:none"<?php } ?>>
                        <div class="labels">
                            Ӧ����
                        </div>
                        <div class="czcontent">
                            <b class="cost czred"><?php echo $preset['0'];?></b> Ԫ
                        </div>
                    </div>
                    </div>
                    <?php if($keke_chongzhi['cardid']) { ?>
                    <div class="cardypaybox" <?php if(($keke_chongzhi['payjsmchid'] && $keke_chongzhi['payjskey']) || ($keke_chongzhi['appid'] && $keke_chongzhi['privatekey'])) { ?>style="display:none"<?php } ?>>
                        <div class="rowss kkclearfix">
                            <div class="labels">��ֵ���ܣ�</div>
                            <div class="czcontent">
                                <input type="text" name="cardid" id="cardid" placeholder="���������ĳ�ֵ����" autocomplete="off">
                                <div class="cardcztip">���뿨�ܺ��� <a>������ֵ</a> ��ɳ�ֵ��<br />���ܳ�ֵʵ�ʵ��˵Ļ��������������ɿ��ܱ���������</div>
                            </div>
                        </div>
                    </div>
                    <?php } ?>
                    <div class="rowss charge-source kkclearfix">
                        <div class="labels">
                            ֧����ʽ��
                        </div>
                        <div class="czcontent">
                            <ul id="charge-source-list" class="charge-source-list kkclearfix" style="margin-bottom:15px;">
                            	<?php if($keke_chongzhi['payjsmchid'] && $keke_chongzhi['payjskey']) { ?>
                                <li class="item kekeweixin <?php if($keke_chongzhi['payjskey'] && $keke_chongzhi['defaultpay']==2 && $keke_chongzhi['payjsmchid']) { ?>active<?php } ?>" source="2">
                                    <a href="javascript:void(0);">
                                        <img src="source/plugin/keke_chongzhi/template/images/pay_01.jpg">
                                    </a>
                                </li>
                                <?php } ?>
                                 <?php if($keke_chongzhi['alipay']) { ?>
                                <li class="item kekealipay <?php if((($keke_chongzhi['payjskey'] && $keke_chongzhi['payjsmchid']) || ($keke_chongzhi['appid'] && $keke_chongzhi['privatekey'])) && $keke_chongzhi['defaultpay']==1) { ?>active<?php } ?>" source="1">
                                    <a href="javascript:void(0);">
                                        <img src="source/plugin/keke_chongzhi/template/images/pay_02.jpg">
                                    </a>
                                </li>
                               <?php } ?>
                                <?php if($keke_chongzhi['cardid']) { ?>
                                 <li class="item chongzhicard <?php if(!$keke_chongzhi['payjsmchid'] && !$keke_chongzhi['payjskey'] && !$keke_chongzhi['appid'] && !$keke_chongzhi['privatekey'] && $keke_chongzhi['cardid']) { ?>active<?php } ?>" source="3">
                                    <a href="javascript:void(0);">
                                        <img src="source/plugin/keke_chongzhi/template/images/pay_03.png">
                                    </a>
                                </li> <?php } ?>
                            </ul>
                            <div id="ewm"></div>
                        </div>
                        <input type="hidden" name="zftype" id="zftype" <?php if(!$keke_chongzhi['payjsmchid'] && !$keke_chongzhi['payjskey'] && !$keke_chongzhi['appid'] && !$keke_chongzhi['privatekey'] && $keke_chongzhi['cardid']) { ?>value="3"<?php } else { ?>value="<?php echo $keke_chongzhi['defaultpay'];?>"<?php } ?>>
                    </div>
                    <div class="rowss charge-submit kkclearfix">
                        <div class="czcontent">
                            <a class="btns btn-submit" id="Submit" href="javascript:;">������ֵ</a>
                        </div>
                    </div>
                    <div class="czsmbox">
                    	<div class="czsm"><?php echo $keke_chongzhi['sm'];?></div>
                    </div>
                </li>
            </ul>
            </form>
            <script src="source/plugin/keke_chongzhi/js/jquery.js" type="text/javascript"></script>
            <script src="source/plugin/keke_chongzhi/js/jquery.qrcode.min.js" type="text/javascript"></script>
<script>jQuery.noConflict();</script>
            <script>
            jQuery(function() {
                var recharge=jQuery(".charge-custom");
                var moneyQuantity=jQuery("#moneyQuantity");
                var cost=jQuery(".cost");
jQuery("input[name=credittype]").on("click", function() {
var credittype=jQuery('input:radio[name="credittype"]:checked').val();
var creditname=jQuery(this).attr("data-creditname");
var bili=jQuery(this).attr("data-bili");
var nowcredits=jQuery(this).attr("data-now");
jQuery('.nowcredit').html('<b class="czred">'+ nowcredits +'</b> '+creditname);
jQuery.get('<?php echo $_G['siteurl'];?>plugin.php?id=keke_chongzhi:ajax', {credittype:credittype,type:'give'},function (datas){
jQuery("#package-list li").each(function() {
var money=jQuery(this).attr("money");
var text=(parseFloat(money)*bili) + creditname;
var nn=jQuery(this).hasClass("zdy");
if(nn){
jQuery(".bilitip").html('ÿ1Ԫ����'+ bili + creditname);
jQuery('.hdtips').hide().html('');
if(recharge.is(':visible')){
cost.html(0);
}
}else{
                        	jQuery(this).children('span').html(text);
jQuery(this).find('cite').remove();
if(!jQuery.isEmptyObject(datas)){
if(datas[money]){
jQuery(this).append('<cite class="giv" id="giv'+money+'"><b>����<i class="givnum">'+datas[money]+'</i></b></cite>');
}
}
}
                    });
}, "json");
 });
                jQuery("#package-list li").on("click", function() {
                            jQuery(this).siblings().removeClass("on");
                            jQuery(this).addClass("on");
                            var nn=jQuery(this).hasClass("zdy");
                            if(nn){
cost.html(0);
                                recharge.show();
jQuery('.hdtips').html('');
                                moneyQuantity.attr("value","");
                                jQuery('#moneyQuantity').bind('input propertychange',function(){
var bilisss=jQuery('input:radio[name="credittype"]:checked').attr("data-bili");
var moneyQuantity=jQuery('#moneyQuantity').val();
var creditnamea=jQuery('input:radio[name="credittype"]:checked').attr("data-creditname");
var giv=parseInt(jQuery("#giv"+moneyQuantity+ "> b .givnum").text());
console.log(giv)
if(giv=='null' || !giv){
giv=0;
}
jQuery('.hdtips').show().html('�����<span class="reddd">'+parseInt(bilisss*moneyQuantity+giv)+'</span>'+creditnamea)
                                    cost.html(moneyQuantity);
                                } );
                            }else{
                                recharge.hide();
jQuery('.hdtips').hide();
                                var money=jQuery(this).attr("money");
                                moneyQuantity.attr("value",money);
                                cost.html(money);
                            };
                        });
                jQuery("#charge-source-list li").on("click", function() {
                            jQuery(this).siblings().removeClass("active");
                            jQuery(this).addClass("active");
                                var source=jQuery(this).attr("source"),moneypaybox=jQuery(".moneypaybox"),cardypaybox=jQuery(".cardypaybox"),ewm=jQuery("#ewm");
                                if(source==3){
jQuery("#ewm").css("height","0px").hide().html('');
cardypaybox.show();
                                    moneypaybox.slideUp();
                                }else{
                                   jQuery("#ewm").css("height","0px").show().html('');
moneypaybox.show();
cardypaybox.hide();
                                }
                                jQuery("#zftype").attr("value",source);
jQuery("#Submit").html('������ֵ');
                        });
                jQuery("#Submit").on("click", function() {
if(jQuery("#ewm").html()!=''){
window.location.href = 'plugin.php?id=keke_chongzhi&p=my';
return false;
}
                        var zftype=jQuery('#zftype').val();
                        if(!zftype){
                            return false;
                        }
                        if(parseFloat(<?php echo $keke_chongzhi['zuidi'];?>)>jQuery("#moneyQuantity").val()){
                            alert('��ͳ�ֵ���Ϊ'+ parseFloat(<?php echo $keke_chongzhi['zuidi'];?>) +'Ԫ');
                            return false;
                        }
var credittypea=jQuery('input:radio[name="credittype"]:checked').val();
if(!credittypea){
alert('��ѡ���ֵ��������');
                            return false;
}
                       
jQuery('#ewm').css("height","258px").html('<img src="source/plugin/keke_chongzhi/template/images/loading.gif" />');
jQuery.get('<?php echo $_G['siteurl'];?>plugin.php?id=keke_chongzhi:payapi', {
 zftype:zftype,moneyQuantity:jQuery("#moneyQuantity").val(),cardid:jQuery("#cardid").val(),credittype:credittypea,time:new Date().getTime(),formhash:"<?php echo FORMHASH;?>"
},function (data){
if(data.err){
showDialog(data.err);
jQuery("#ewm").hide().html('');
}else if(data.ewmurl){
<?php if($keke_chongzhi['qr']==2) { ?>
jQuery('#ewm').show().html('<img src="'+data.ewmurl+'">');
<?php } else { ?>
jQuery('#ewm').show().html('').qrcode({width:200,height:200,correctLevel:0,text:data.ewmurl});
<?php } ?>
var orderid=data.orderid;
setInterval(function(){
jQuery.get('<?php echo $_G['siteurl'];?>plugin.php?id=keke_chongzhi:checkorder', {orderid:orderid,time:new Date().getTime(),formhash:"<?php echo FORMHASH;?>"},function (datas){
if(datas.state==1){window.location.href = '<?php echo $returnurl;?>';return false;}else{return false;}
}, "json");
},2000); 
jQuery("#Submit").html('����֧�����');
}else if(data.cardok){
showDialog(data.cardok,'right', '', 'window.location.href = \'plugin.php?id=keke_chongzhi&p=my\'',true,'','','','','',2);
}
}, "json");
                       
                        });
            });
            </script>
        <?php } ?>
        </div>
</div>
    
    <?php include template('common/footer'); ?>